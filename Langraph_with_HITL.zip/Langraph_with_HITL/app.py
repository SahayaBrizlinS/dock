# main.py
from __future__ import annotations

import os
import sqlite3
import uuid
from datetime import datetime
from typing import Optional, Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

# LangChain / LangGraph
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.graph import StateGraph, END, MessagesState
from langgraph.types import Command, interrupt
from langgraph.checkpoint.sqlite import SqliteSaver

# -------------------------
# CONFIG
# -------------------------
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyAoVxsWCPQke5kQTF4X6JXbBFUodlPM2mw")
GEMINI_MODEL = "gemini-2.0-flash"
SQLITE_FILE = "memory.db"  # both LangGraph checkpoints + app tables live here

# -------------------------
# DB helpers (app-level tables)
# -------------------------
def db_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(SQLITE_FILE, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db() -> None:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS sessions (
        thread_id TEXT PRIMARY KEY,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    );""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS resumes (
        thread_id TEXT PRIMARY KEY,
        resume_text TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY(thread_id) REFERENCES sessions(thread_id)
    );""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS qa_pairs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        thread_id TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        approved INTEGER DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY(thread_id) REFERENCES sessions(thread_id)
    );""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS approvals (
        thread_id TEXT PRIMARY KEY,
        question TEXT NOT NULL,
        draft_answer TEXT NOT NULL,
        waiting_for_approval INTEGER DEFAULT 1,
        created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY(thread_id) REFERENCES sessions(thread_id)
    );""")
    conn.commit()
    conn.close()

def upsert_session(thread_id: str) -> None:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO sessions(thread_id) VALUES (?)
        ON CONFLICT(thread_id) DO UPDATE SET updated_at=datetime('now')
    """, (thread_id,))
    conn.commit()
    conn.close()

def create_new_session() -> str:
    thread_id = str(uuid.uuid4())
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("INSERT INTO sessions(thread_id) VALUES (?)", (thread_id,))
    conn.commit()
    conn.close()
    return thread_id

def list_sessions() -> list[dict]:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("SELECT thread_id, created_at, updated_at FROM sessions ORDER BY updated_at DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

def save_resume(thread_id: str, resume_text: str) -> None:
    upsert_session(thread_id)
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO resumes(thread_id, resume_text) VALUES(?, ?)
        ON CONFLICT(thread_id) DO UPDATE SET resume_text=excluded.resume_text, updated_at=datetime('now')
    """, (thread_id, resume_text))
    conn.commit()
    conn.close()

def get_resume(thread_id: str) -> Optional[str]:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("SELECT resume_text FROM resumes WHERE thread_id = ?", (thread_id,))
    row = cur.fetchone()
    conn.close()
    return row["resume_text"] if row else None

def list_qa_pairs(thread_id: str) -> list[dict]:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT question, answer, approved, created_at
        FROM qa_pairs WHERE thread_id = ?
        ORDER BY id ASC
    """, (thread_id,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

def set_pending_approval(thread_id: str, question: str, draft_answer: str) -> None:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO approvals (thread_id, question, draft_answer, waiting_for_approval)
        VALUES (?, ?, ?, 1)
        ON CONFLICT(thread_id) DO UPDATE SET
          question=excluded.question,
          draft_answer=excluded.draft_answer,
          waiting_for_approval=1,
          created_at=datetime('now')
    """, (thread_id, question, draft_answer))
    conn.commit()
    conn.close()

def get_pending_approval(thread_id: str) -> Optional[dict]:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT thread_id, question, draft_answer, waiting_for_approval, created_at
        FROM approvals WHERE thread_id = ?
    """, (thread_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def clear_pending_approval(thread_id: str) -> None:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM approvals WHERE thread_id = ?", (thread_id,))
    conn.commit()
    conn.close()

def commit_qa(thread_id: str, question: str, answer: str) -> None:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO qa_pairs(thread_id, question, answer, approved)
        VALUES (?, ?, ?, 1)
    """, (thread_id, question, answer))
    conn.commit()
    conn.close()

def delete_thread_everything(thread_id: str) -> None:
    conn = db_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM approvals WHERE thread_id = ?", (thread_id,))
    cur.execute("DELETE FROM qa_pairs WHERE thread_id = ?", (thread_id,))
    cur.execute("DELETE FROM resumes WHERE thread_id = ?", (thread_id,))
    cur.execute("DELETE FROM sessions WHERE thread_id = ?", (thread_id,))
    conn.commit()
    conn.close()
    # Note: LangGraph checkpoint rows remain; recommended approach: use a new thread_id after reset.

# -------------------------
# LangGraph + LLM (same HITL design)
# -------------------------
_lg_sql_conn = sqlite3.connect(SQLITE_FILE, check_same_thread=False)
checkpointer = SqliteSaver(_lg_sql_conn)

model = ChatGoogleGenerativeAI(
    model=GEMINI_MODEL,
    google_api_key=GEMINI_API_KEY
)

SYSTEM_GUIDE = (
    "You are a resume assistant. Answer using the candidate's resume and approved Q/A history. "
    "Be concise, factual, and avoid fabrications. If info is missing, say so."
)

def build_prompt(resume_text: str, qa_history: list[dict], question: str) -> list:
    messages: list = []
    from langchain_core.messages import SystemMessage as _SystemMessage
    messages.append(_SystemMessage(content=SYSTEM_GUIDE))
    messages.append(_SystemMessage(content=f"FULL RESUME:\n{resume_text}"))
    if qa_history:
        hist = "\n".join([f"Q: {h['question']}\nA: {h['answer']}" for h in qa_history if h.get("approved")])
        messages.append(_SystemMessage(content=f"APPROVED Q/A HISTORY:\n{hist}"))
    messages.append(HumanMessage(content=question))
    return messages

# Graph nodes
def node_generate_draft(state: MessagesState):
    last_user_msg = next((m for m in reversed(state["messages"]) if isinstance(m, HumanMessage)), None)
    if last_user_msg is None:
        return {"messages": [AIMessage(content="No user question found.")]}
    thread_id = None
    from langchain_core.messages import SystemMessage as _SystemMessage
    for m in state["messages"]:
        if isinstance(m, _SystemMessage) and str(m.content).startswith("THREAD_ID:"):
            thread_id = str(m.content).split("THREAD_ID:", 1)[1].strip()
            break
    if not thread_id:
        return {"messages": [AIMessage(content="Thread ID context missing.")]}
    resume = get_resume(thread_id)
    if not resume:
        return {"messages": [AIMessage(content="No resume uploaded for this thread. Please upload a resume first.")]}
    history = list_qa_pairs(thread_id)
    prompt_messages = build_prompt(resume, history, last_user_msg.content)
    draft = model.invoke(prompt_messages)
    set_pending_approval(thread_id, last_user_msg.content, draft.content)
    return {"messages": [AIMessage(content=f"[DRAFT]\n{draft.content}")]}

def node_approval_gate(state: MessagesState) -> Command[Literal["node_commit_qa", END]]:
    thread_id = None
    from langchain_core.messages import SystemMessage as _SystemMessage
    for m in state["messages"]:
        if isinstance(m, _SystemMessage) and str(m.content).startswith("THREAD_ID:"):
            thread_id = str(m.content).split("THREAD_ID:", 1)[1].strip()
            break
    pending = get_pending_approval(thread_id) if thread_id else None
    if not pending or not pending.get("waiting_for_approval"):
        return Command(goto=END)
    payload = {
        "question": pending["question"],
        "draft_answer": pending["draft_answer"],
        "thread_id": thread_id,
        "instruction": "Approve to commit this Q/A. Or Reject & Reset to wipe this thread."
    }
    resume_payload = interrupt(payload)
    action = resume_payload.get("action")
    if action == "approve":
        return Command(goto="node_commit_qa")
    return Command(goto=END)

def node_commit_qa(state: MessagesState):
    thread_id = None
    from langchain_core.messages import SystemMessage as _SystemMessage
    for m in state["messages"]:
        if isinstance(m, _SystemMessage) and str(m.content).startswith("THREAD_ID:"):
            thread_id = str(m.content).split("THREAD_ID:", 1)[1].strip()
            break
    pending = get_pending_approval(thread_id) if thread_id else None
    if pending and pending.get("waiting_for_approval"):
        commit_qa(thread_id, pending["question"], pending["draft_answer"])
        clear_pending_approval(thread_id)
        return {"messages": [AIMessage(content=pending["draft_answer"])]}
    return {"messages": [AIMessage(content="No pending approval to commit.")]}

builder = StateGraph(MessagesState)
builder.add_node("node_generate_draft", node_generate_draft)
builder.add_node("node_approval_gate", node_approval_gate)
builder.add_node("node_commit_qa", node_commit_qa)
builder.set_entry_point("node_generate_draft")
builder.add_edge("node_generate_draft", "node_approval_gate")
builder.add_edge("node_commit_qa", END)
graph = builder.compile(checkpointer=checkpointer)

# -------------------------
# FastAPI endpoints + UI
# -------------------------
app = FastAPI(title="Resume QA (HITL) - Multi-thread", version="1.1")

class UploadResumeReq(BaseModel):
    thread_id: str = Field(..., example="thread1")
    resume_text: str

class AskReq(BaseModel):
    thread_id: str = Field(..., example="thread1")
    question: str

class ApproveReq(BaseModel):
    thread_id: str = Field(..., example="thread1")
    action: Literal["approve"] = "approve"

class ResetReq(BaseModel):
    thread_id: str = Field(..., example="thread1")

@app.on_event("startup")
def on_startup():
    init_db()

@app.post("/new_chat")
def new_chat():
    thread_id = create_new_session()
    return {"thread_id": thread_id}

@app.get("/list_chats")
def get_chats():
    rows = list_sessions()
    return {"chats": rows}

@app.post("/upload_resume")
def upload_resume(req: UploadResumeReq):
    upsert_session(req.thread_id)
    save_resume(req.thread_id, req.resume_text)
    return {"status": "ok", "thread_id": req.thread_id, "bytes": len(req.resume_text)}

@app.post("/ask")
def ask(req: AskReq):
    messages = [
        SystemMessage(content=f"THREAD_ID:{req.thread_id}"),
        HumanMessage(content=req.question),
    ]
    config = {"configurable": {"thread_id": req.thread_id}}
    result = graph.invoke({"messages": messages}, config=config, stream_mode="updates")
    pending = get_pending_approval(req.thread_id)
    next_nodes = graph.get_state(config).next
    return {"result": str(result), "next": next_nodes, "pending_approval": pending}

@app.post("/approve")
def approve(req: ApproveReq):
    config = {"configurable": {"thread_id": req.thread_id}}
    result = graph.invoke(Command(resume={"action": req.action}), config=config)
    next_nodes = graph.get_state(config).next
    return {"result": str(result), "next": next_nodes, "pending_approval": get_pending_approval(req.thread_id)}

@app.post("/reject_reset")
def reject_reset(req: ResetReq):
    delete_thread_everything(req.thread_id)
    return {"status": "reset", "thread_id": req.thread_id, "hint": "Start with /new_chat then /upload_resume"}

@app.get("/session/{thread_id}")
def session_info(thread_id: str):
    data = {
        "thread_id": thread_id,
        "resume_present": bool(get_resume(thread_id)),
        "resume": get_resume(thread_id),
        "qa_history": list_qa_pairs(thread_id),
        "pending_approval": get_pending_approval(thread_id),
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    return data

# -------------------------
# Minimal UI (HTML/JS) with chat sidebar
# -------------------------
HTML = r"""
<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Resume QA — Multi-thread</title>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
:root{--bg:#0f172a;--panel:#111827;--text:#e5e7eb;--muted:#9ca3af;--accent:#60a5fa;--ok:#22c55e;--warn:#f59e0b;--err:#ef4444}
*{box-sizing:border-box}body{margin:0;font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto;background:var(--bg);color:var(--text)}
.header{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:#0b1220;border-bottom:1px solid #1f2937}
.header h1{margin:0;font-size:16px;color:#d1d5db}
.layout{display:flex;height:calc(100vh - 56px)}
.sidebar{width:280px;background:var(--panel);padding:12px;border-right:1px solid #1f2937;overflow:auto}
.main{flex:1;padding:16px;display:flex;flex-direction:column;gap:12px}
.card{background:var(--panel);border:1px solid #1f2937;border-radius:12px;padding:12px}
.thread-list{list-style:none;padding:0;margin:8px 0;display:flex;flex-direction:column;gap:6px}
.thread-item{padding:8px;border-radius:8px;background:#0b1220;border:1px solid #111827;cursor:pointer}
.thread-item.active{background:#06203b;border-color:#234e7a}
.input,textarea{width:100%;background:#0b1220;color:var(--text);border:1px solid #1f2937;border-radius:8px;padding:8px}
.controls{display:flex;gap:8px;margin-top:8px}
.chat{flex:1;overflow:auto;padding:8px;display:flex;flex-direction:column;gap:10px;max-height:70vh}
.bubble{padding:10px 12px;border-radius:12px;max-width:80%}
.user{align-self:flex-end;background:#1e293b}
.ai{align-self:flex-start;background:#0b1220;border:1px solid #1f2937}
.draft{outline:2px dashed var(--warn)}
.meta{font-size:12px;color:var(--muted);margin-top:6px}
.button{padding:8px 10px;border-radius:8px;border:1px solid #2f3a4a;background:#111827;color:var(--text);cursor:pointer}
.button.primary{background:var(--accent);border-color:#3b82f6}
.button.ok{background:var(--ok);border-color:#16a34a}
.button.warn{background:var(--err);border-color:#b91c1c}
.small{font-size:12px;color:var(--muted)}
</style>
</head>
<body>
<div class="header">
  <h1>Resume QA — Multi-thread (HITL)</h1>
  <div style="display:flex;gap:8px;align-items:center">
    <button class="button" onclick="newChat()">➕ New Chat</button>
    <button class="button" onclick="loadChats()">Refresh</button>
  </div>
</div>

<div class="layout">
  <div class="sidebar">
    <div class="card">
      <div class="small">Threads</div>
      <ul id="threads" class="thread-list"></ul>
    </div>

    <div style="height:12px"></div>

    <div class="card">
      <div class="small">Resume (for selected thread)</div>
      <textarea id="resume" rows="8" class="input" placeholder="Paste resume text..."></textarea>
      <div class="controls" style="margin-top:8px">
        <button class="button primary" onclick="uploadResume()">Upload / Replace</button>
        <button class="button" onclick="clearResumeInput()">Clear</button>
      </div>
    </div>

    <div style="height:12px"></div>

    <div class="card">
      <div class="small">Pending approval</div>
      <div id="approvalBox" class="meta">None</div>
      <div class="controls" style="margin-top:8px">
        <button class="button ok" onclick="approve()">Approve</button>
        <button class="button warn" onclick="rejectReset()">Reject & Reset</button>
      </div>
    </div>

    <div style="height:12px"></div>

    <div class="card">
      <div class="small">Session info</div>
      <div id="sessionInfo" class="meta">–</div>
    </div>
  </div>

  <div class="main">
    <div class="card" style="flex:1;display:flex;flex-direction:column">
      <div class="chat" id="chat"></div>
      <div style="display:flex;gap:8px;margin-top:8px">
        <input id="question" class="input" type="text" placeholder="Ask a question about the resume..." />
        <button class="button primary" onclick="ask()">Ask</button>
      </div>
    </div>
  </div>
</div>

<script>
let currentThread = null;

const $ = s => document.querySelector(s);

async function loadChats(){
  const res = await fetch('/list_chats');
  const data = await res.json();
  const list = $('#threads');
  list.innerHTML = '';
  data.chats.forEach(c => {
    const li = document.createElement('li');
    li.className = 'thread-item';
    li.textContent = (c.thread_id).slice(0,8) + " — " + (c.updated_at || c.created_at || '');
    li.onclick = () => switchChat(c.thread_id);
    if (c.thread_id === currentThread) li.classList.add('active');
    list.appendChild(li);
  });
}

async function newChat(){
  const res = await fetch('/new_chat', {method:'POST'});
  const j = await res.json();
  currentThread = j.thread_id;
  await loadChats();
  await restore();
}

async function switchChat(threadId){
  currentThread = threadId;
  await loadChats();
  await restore();
}

function addBubble(role, text, draft=false){
  const chat = $('#chat');
  const b = document.createElement('div');
  b.className = 'bubble ' + (role === 'user' ? 'user' : 'ai') + (draft ? ' draft' : '');
  b.textContent = text;
  chat.appendChild(b);
  chat.scrollTop = chat.scrollHeight;
}

async function uploadResume(){
  if (!currentThread){ alert('Select or create a thread first'); return; }
  const resume = $('#resume').value.trim();
  if (!resume){ alert('Paste resume text'); return; }
  const res = await fetch('/upload_resume', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ thread_id: currentThread, resume_text: resume })
  });
  const j = await res.json();
  alert('Saved resume for ' + j.thread_id);
  await restore();
}

function clearResumeInput(){
  $('#resume').value = '';
}

async function ask(){
  if (!currentThread){ alert('Select or create a thread first'); return; }
  const q = $('#question').value.trim();
  if (!q) return;
  addBubble('user', q);
  $('#question').value = '';
  const res = await fetch('/ask', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ thread_id: currentThread, question: q })
  });
  const j = await res.json();
  const pending = j.pending_approval;
  if (pending && pending.draft_answer){
    addBubble('ai', '[DRAFT]\\n' + pending.draft_answer, true);
  }
  await restore();
}

async function approve(){
  if (!currentThread){ alert('Select a thread'); return; }
  const res = await fetch('/approve', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ thread_id: currentThread, action: 'approve' })
  });
  await res.json();
  await restore();
}

async function rejectReset(){
  if (!currentThread){ alert('Select a thread'); return; }
  if (!confirm('This will wipe resume & history for this thread. Continue?')) return;
  const res = await fetch('/reject_reset', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ thread_id: currentThread })
  });
  await res.json();
  $('#resume').value = '';
  $('#chat').innerHTML = '';
  $('#approvalBox').textContent = 'None';
  $('#sessionInfo').textContent = 'Reset complete';
  await loadChats();
}

function renderHistory(qa){
  const chat = $('#chat');
  chat.innerHTML = '';
  (qa || []).forEach(item => {
    addBubble('user', item.question);
    addBubble('ai', item.answer);
  });
}

function renderApproval(pending){
  const box = $('#approvalBox');
  if (!pending || !pending.waiting_for_approval){
    box.textContent = 'None';
    return;
  }
  box.innerHTML = '<div class="small">Q:</div><div style="white-space:pre-wrap;margin:6px 0 10px">' +
    pending.question + '</div><div class="small">Draft:</div><div style="white-space:pre-wrap">' + pending.draft_answer + '</div>';
}

async function restore(){
  if (!currentThread) return;
  const res = await fetch('/session/' + encodeURIComponent(currentThread));
  const data = await res.json();
  renderHistory(data.qa_history);
  renderApproval(data.pending_approval);
  $('#sessionInfo').textContent = `thread: ${data.thread_id} | resume: ${data.resume_present ? 'yes' : 'no'} | time: ${data.timestamp}`;
  if (data.resume) $('#resume').value = data.resume;
}

window.addEventListener('load', async () => {
  await loadChats();
  // if there is at least one session, choose the most recent
  const listRes = await fetch('/list_chats');
  const list = await listRes.json();
  if (list.chats && list.chats.length && !currentThread){
    currentThread = list.chats[0].thread_id;
    await restore();
  }
});
</script>
</body>
</html>
"""

@app.get("/ui", response_class=HTMLResponse, include_in_schema=False)
def ui():
    return HTML
