import requests
from rag_pipeline.embeddings.base import EmbeddingBackend

class OllamaEmbedder(EmbeddingBackend):
    def __init__(self, model: str, base_url: str):
        self.base_url = base_url
        self.model = model

    def embed(self, text: str) -> list[float]:  # ✅ Must match abstract method
        if not text.strip():
            return []
        try:
            res = requests.post(
                f"{self.base_url}/api/embeddings",
                json={"model": self.model, "prompt": text}
            )
            res.raise_for_status()
            return res.json().get("embedding", [])
        except requests.RequestException as e:
            print(f"[OllamaEmbedder] Error: {e}")
            return []

    def embed_section_chunks(self, chunks):  # ✅ Optional helper for bulk ingestion
        embeddings = []
        valid_chunks = []
        for chunk in chunks:
            text = chunk.get("content", "")
            if not text.strip():
                continue
            emb = self.embed(text)
            if emb:
                embeddings.append(emb)
                valid_chunks.append(chunk)
        return embeddings, valid_chunks
