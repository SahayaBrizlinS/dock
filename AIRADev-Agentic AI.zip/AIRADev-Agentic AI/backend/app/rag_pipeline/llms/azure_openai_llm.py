from .base import BaseLLM
from openai import AzureOpenAI

class AzureOpenAILLM(BaseLLM):
    def __init__(self, model, base_url, api_key, deployment_name, model_version, api_type):
        self.model = model
        self.client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=base_url.rstrip("/"),
            api_version=model_version
        )

    def generate(self, prompt, context, question, temperature, max_tokens):
        try:
            messages = [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": f"prompt:\n{prompt}\n\nQuestion: {question}"}
            ]

            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )

            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"[Error in OpenAIChatModel]: {e}"
