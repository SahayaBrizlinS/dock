import re

def extract_standard_number(standard):
    """
    Extracts the core standard number in the format 'xxxx-x:yyyy'
    - Handles optional/messy spaces around dash and colon.
    - Removes any suffix like '/Amd 1:2019' or '/AC:2006'.
    """
    # Step 1: Normalize the dash and colon (e.g., '10993 - 7 : 2008' → '10993-7:2008')
    standard = re.sub(r'\s*-\s*', '-', standard)   # Normalize dash
    standard = re.sub(r'\s*:\s*', ':', standard)   # Normalize colon

    # Step 2: Extract pattern like '10993-7:2008'
    match = re.search(r'\b(\d{2,5}-\d{1,2}:\d{4})\b', standard)
    if match:
        return match.group(1).strip()

    # Fallback: match '10993-7'
    match = re.search(r'\b(\d{2,5}-\d{1,2})\b', standard)
    if match:
        return match.group(1).strip()

    # Final fallback: match any 3–5 digit number
    match = re.search(r'\b(\d{3,5})\b', standard)
    if match:
        return match.group(1).strip()

    return standard.strip()