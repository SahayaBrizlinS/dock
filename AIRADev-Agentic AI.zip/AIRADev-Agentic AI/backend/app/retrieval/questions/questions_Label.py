def questions_Label():
    QUESTION_TEMPLATES = {
	
        "Questions":[
            
            {
                "question":"Extract the Part Number, Revision number, and Date from the header area of the {document_id} document for product {product_code}.",
                "column":"3",
                "repeat":"True",
                "dictionary_element":"Date",
                "prompt_template":"part_number_label",
                "document_id":"RMC4916_0719004306_IFU_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}"
            },
            {
                "question":"Extract the Part Number, Revision number, and Date from the header area of the {document_id} document for product {product_code}.",
                "column":"5",
                "repeat":"True",
                "dictionary_element":"Date",
                "prompt_template":"part_number_label",
                "document_id":"RMC4916_0736003737_POUCH_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            },
            {
                "question":"Extract the Part Number, Revision number, and Date from the header area of the {document_id} document for product {product_code}.",
                "column":"7",
                "repeat":"True",
                "dictionary_element":"Date",
                "prompt_template":"part_number_label",
                "document_id":"RMC4916_0738002356_Carton_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            },
            {
                "question":"Extract the intended purpose from the section-text of the document {document_id} for product {product_code}.",
                "column":"4",
                "row":"13",
                "dictionary_element":"Intended Use",
                "prompt_template":"intended_purpose_label",
                "full_document_search":"Yes",
                "document_id":"RMC4916_0719004306_IFU_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}",
                "where_document" : "{\"$contains\": \"Intended Purpose\"}"
            },
            {
                "question":"Extract the intended purpose from the section-text of the document {document_id} for product {product_code}.",
                "column":"6",
                "row":"13",
                "dictionary_element":"Intended Use",
                "prompt_template":"intended_purpose_label",
                "document_id":"RMC4916_0736003737_POUCH_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            },
            {
                "question":"Extract the intended purpose from the section-text of the document {document_id} for product {product_code}.",
                "column":"8",
                "row":"13",
                "dictionary_element":"Intended Use",
                "prompt_template":"intended_purpose_label",
                "document_id":"RMC4916_0738002356_Carton_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            },
            {
                "question":"Extract the Indication for Use from the document {document_id} for product {product_code}.",
                "column":"4",
                "row":"14",
                "dictionary_element":"Indication for Use",
                "prompt_template":"indication_for_use_label",
                "document_id":"RMC4916_0719004306_IFU_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}"
            },
            {
                "question":"Extract the Indication for Use from the document {document_id} for product {product_code}.",
                "column":"6",
                "row":"14",
                "dictionary_element":"Indication for Use",
                "prompt_template":"indication_for_use_label",
                "document_id":"RMC4916_0736003737_POUCH_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            },
            {
                "question":"Extract the Indication for Use from the document {document_id} for product {product_code}.",
                "column":"8",
                "row":"14",
                "dictionary_element":"Indication for Use",
                "prompt_template":"indication_for_use_label",
                "document_id":"RMC4916_0738002356_Carton_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            },
            {
                "question":"Extract the Contraindications from the document {document_id} for product {product_code}.",
                "column":"4",
                "row":"15",
                "dictionary_element":"Contraindications",
                "prompt_template":"contraindications_label",
                "document_id":"RMC4916_0719004306_IFU_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}"
            },
            {
                "question":"Extract the Contraindications from the document {document_id} for product {product_code}.",
                "column":"6",
                "row":"15",
                "dictionary_element":"Contraindications",
                "prompt_template":"contraindications_label",
                "document_id":"RMC4916_0736003737_POUCH_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            },
            {
                "question":"Extract the Contraindications from the document {document_id} for product {product_code}.",
                "column":"8",
                "row":"15",
                "dictionary_element":"Contraindications",
                "prompt_template":"contraindications_label",
                "document_id":"RMC4916_0738002356_Carton_LABEL",
                "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            }
            # {
            #     "question":"Extract the medical claims from the document {document_id} for product {product_code}.",
            #     "column":"4",
            #     "dictionary_element":"Claims",
            #     "prompt_template":"claims_label",
            #     "document_id":"RMC4916_0719004306_IFU_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical claims from the document {document_id} for product {product_code} under Claims section.",
            #     "column":"6",
            #     "dictionary_element":"Claims",
            #     "prompt_template":"claims_label",
            #     "document_id":"RMC4916_0736003737_POUCH_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical claims from the document {document_id} for product {product_code} under Claims section.",
            #     "column":"8",
            #     "dictionary_element":"Claims",
            #     "prompt_template":"claims_label",
            #     "document_id":"RMC4916_0738002356_Carton_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical warnings from the document {document_id} for product {product_code}.",
            #     "column":"4",
            #     "dictionary_element":"Warnings",
            #     "prompt_template":"warnings_label",
            #     "document_id":"RMC4916_0719004306_IFU_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical warnings from the document {document_id} for product {product_code}.",
            #     "column":"6",
            #     "dictionary_element":"Warnings",
            #     "prompt_template":"warnings_label",
            #     "document_id":"RMC4916_0736003737_POUCH_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical warnings from the document {document_id} for product {product_code}.",
            #     "column":"8",
            #     "dictionary_element":"Warnings",
            #     "prompt_template":"warnings_label",
            #     "document_id":"RMC4916_0738002356_Carton_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical cautions from the document {document_id} for product {product_code}.",
            #     "column":"4",
            #     "dictionary_element":"Cautions",
            #     "prompt_template":"cautions_label",
            #     "document_id":"RMC4916_0719004306_IFU_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0719004306_IFU_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical cautions from the document {document_id} for product {product_code}.",
            #     "column":"6",
            #     "dictionary_element":"Cautions",
            #     "prompt_template":"cautions_label",
            #     "document_id":"RMC4916_0736003737_POUCH_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0736003737_POUCH_LABEL\"}}"
            # },
            # {
            #     "question":"Extract the medical cautions from the document {document_id} for product {product_code}.",
            #     "column":"8",
            #     "dictionary_element":"Cautions",
            #     "prompt_template":"cautions_label",
            #     "document_id":"RMC4916_0738002356_Carton_LABEL",
            #     "where_filter": "{\"document_id\": {\"$eq\": \"RMC4916_0738002356_Carton_LABEL\"}}"
            # }
        ]
    }
    return QUESTION_TEMPLATES


def priority():
    priority_list = ["Intended Use","Indication for Use","Contraindications","Claims","Warnings","Cautions","Date"]
    return priority_list
