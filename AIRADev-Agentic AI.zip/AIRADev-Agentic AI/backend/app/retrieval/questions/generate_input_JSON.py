import pandas as pd
import psycopg2
import json
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

def clean_float_values(obj):
    """Recursively convert float values like 3.0 to int 3 in any JSON structure."""
    if isinstance(obj, dict):
        return {k: clean_float_values(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_float_values(item) for item in obj]
    elif isinstance(obj, float):
        return int(obj) if obj.is_integer() else obj
    elif isinstance(obj, str):
        try:
            f = float(obj)
            return int(f) if f.is_integer() else f
        except:
            return obj
    else:
        return obj

def remove_keys_from_nested_sections(data, keys_to_remove):
    """Remove specified keys from group and link sections only."""
    for item in data:
        if "group" in item:
            item["group"] = [
                {k: v for k, v in g.items() if k not in keys_to_remove}
                for g in item["group"]
            ]
        if "link" in item:
            item["link"] = [
                {k: v for k, v in l.items() if k not in keys_to_remove}
                for l in item["link"]
            ]
    return data

def generate_json_from_master(pipeline_config, master_table, group_table, link_table):
    
    db_config = {
        'host': pipeline_config["postgres_host"],
        'port': pipeline_config["postgres_port"],
        'dbname': pipeline_config["postgres_db"],
        'user': pipeline_config["postgres_user"],
        'password': pipeline_config["postgres_password"]
    }
    conn = psycopg2.connect(**db_config)
    cur = conn.cursor()

    # Load all tables
    cur.execute(f'SELECT * FROM "{master_table}";')
    master_rows = cur.fetchall()
    master_cols = [desc[0] for desc in cur.description]

    cur.execute(f'SELECT * FROM "{group_table}";')
    group_rows = cur.fetchall()
    group_cols = [desc[0] for desc in cur.description]

    cur.execute(f'SELECT * FROM "{link_table}";')
    link_rows = cur.fetchall()
    link_cols = [desc[0] for desc in cur.description]

    result = []
    QUESTION_TEMPLATES = ""
    
    for row in master_rows:
        row_dict = dict(zip(master_cols, row))

        # Safely extract and normalize Type
        type_raw = row_dict.get("Type")
        type_value = str(type_raw).strip().lower() if type_raw is not None else ""

        # Enrich with group or link data if applicable
        if type_value == "group":
            group_id = row_dict.get("GroupID")
            if group_id:  # Ensure GroupID exists
                logging.info(f"Fetching group items for GroupID: {group_id}")
                
                # Fetch the related group items from group_rows
                group_items = [
                    dict(zip(group_cols, g_row))
                    for g_row in group_rows
                    if str(g_row[group_cols.index("GroupID")]) == str(group_id)  # Ensure GroupID is a string for comparison
                ]
                logging.info(f"Fetched {len(group_items)} group items for GroupID: {group_id}")
                
                # If there are no group items, log a message
                if not group_items:
                    logging.warning(f"No group items found for GroupID: {group_id}")
                
                # Structure the group data as per the example format
                group_data = []
                for group_item in group_items:
                    group_dict = {
                        "Question": group_item.get("Question"),
                        "Prompt_Template": group_item.get("Prompt_Template"),
                        "Where_Filter": group_item.get("Where_Filter"),
                        "DocumentID": group_item.get("DocumentID"),
                        "FullText": group_item.get("FullText"),
                        "Where_Document": group_item.get("Where_Document"),
                        "Type": "Group"
                        
                    }
                    group_data.append(group_dict)

                row_dict["Group"] = group_data
            else:
                logging.warning(f"GroupID is missing or invalid for the record: {row_dict}")

        elif type_value == "link":
            link_id = row_dict.get("LinkID")
            link_items = [
                dict(zip(link_cols, l_row))
                for l_row in link_rows
                if str(l_row[link_cols.index("LinkID")]) == str(link_id)
            ]
            row_dict["Link"] = link_items

        # Append enriched or plain row
        result.append(row_dict)

    # Step 1: Clean float values
    result = clean_float_values(result)

    # Step 2: Remove unwanted keys from group/link sections
    keys_to_remove = ["GroupID", "SetID", "Document_Type", "LinkID", "ID"]
    result = remove_keys_from_nested_sections(result, keys_to_remove)

    # Generate final JSON with Questions
    QUESTION_TEMPLATES = json.dumps({"Questions": result}, indent=2)

    return QUESTION_TEMPLATES
