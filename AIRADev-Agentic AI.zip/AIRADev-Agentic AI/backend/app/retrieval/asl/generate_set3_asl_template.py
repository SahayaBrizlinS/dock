import openpyxl
import os
from openpyxl.styles import Border, Side
import logging
import sys,copy
import ast
from collections import defaultdict, OrderedDict
from openpyxl.utils import column_index_from_string
from langchain.globals import set_llm_cache
from langchain_community.cache import InMemoryCache
# from .questions_set3 import questions
# from .retrieve_content_template import retrieve_collection_data_template
import re
import json
from typing import List, Dict
from datetime import datetime
# from .extract_standard_description import extract_description_for_standard
# from .sota_updates import read_standards_from_sota_excel,update_sota_field,update_consistency_flags,update_remarks_based_on_sota
from .set3_asl_helper import read_standards_from_excel,extract_reference_number_to_search,get_web_scrap_data,initialize_driver,write_data_to_excel,match_reference,update_remarks


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)

dict_data = defaultdict(list)

def extract_product_code(sheet):
    for row in sheet.iter_rows():
        for cell in row:
            if cell.value and isinstance(cell.value, str) and "product code" in cell.value.lower():
                adjacent_value = sheet.cell(row=cell.row, column=cell.column + 1).value
                return str(adjacent_value).strip() if adjacent_value else None
    return None

def extract_response_array(llama_response):
    try:
        # Try to parse the response directly as JSON (list of dictionaries)
        json_data = llama_response.strip()

        # If the response is wrapped in markdown backticks, extract the JSON inside it
        code_block = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", json_data, re.DOTALL)
        if code_block:
            json_data = code_block.group(1)

        # Attempt to load the JSON data into a Python object (list of dictionaries)
        parsed_data = json.loads(json_data)

        # Check if parsed_data is a list and contains dictionaries
        if isinstance(parsed_data, list) and all(isinstance(item, dict) for item in parsed_data):
            return parsed_data
        else:
            logging.warning(f"Unexpected format in LLaMA response: {parsed_data}")
            return []
    
    except Exception as e:
        logging.warning(f"Failed to extract array: {e}")
        return []


# file_path = "./input/asl.xlsx"
# output_file_path="./output"
#template_file_path = "./Template/Set-III-Template.xlsx"


def generate_set3_asl_template(input_file_path, output_file_path, pipeline_config):
   
    aslFile = f"{pipeline_config.get('sotafile_path', 'data')}/asl.xlsx"
    raw_standards = read_standards_from_excel(aslFile,"ASL Table")
    driver=initialize_driver()

    for item in raw_standards:
        standard=extract_reference_number_to_search(item["ASL"])
        print(standard)

        raw_data=get_web_scrap_data(driver,standard)
        for entry in raw_data:
            entry["ASL"]=item["ASL"]
        print(raw_data)
        # generate_text_file("raw_data.txt",raw_data)

        #filter_data=match_reference(raw_data,standard)

        value = raw_data[0].get("Standards Developing Organization", "")
        if value=="Not Found":
            print("Skipping — empty Standards Developing Organization")
            filter_data=raw_data
            item["ExtentofRecognition"]=filter_data[0].get("Extent of Recognition", "").strip()
            item["Matched"]="No"
            item["Year_Extracted"]="0000"
            #combine_Data.extend(filter_data)
        else:
            print("Proceed with processing")
            filter_data=match_reference(raw_data,standard)
            item["ExtentofRecognition"]=filter_data[0].get("Extent of Recognition", "").strip()
            item["Matched"]=filter_data[0].get("Matched", "").strip()
            item["Year_Extracted"]=filter_data[0].get("Year Extracted", "").strip()
            #combine_Data.extend(filter_data)

        res=update_remarks(item["ExtentofRecognition"],item["Year_Extracted"],item["MaxVersion"])
        item["Remarks"]=res
    driver.quit()

    # Create a deep copy
    new_data = copy.deepcopy(raw_standards)

    # Remove specified keys
    for item in new_data:
        item.pop("MaxVersion", None)
        item.pop("Matched", None)

    print(new_data)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    output_file_path = f"{output_file_path}-{timestamp}.xlsx"
    write_data_to_excel(template_path=input_file_path,output_path=output_file_path,data=new_data)

#read_standards_from_excel,extract_reference_number_to_search,get_web_scrap_data,initialize_driver,write_data_to_excel,match_reference

