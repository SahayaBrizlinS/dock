from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from .standard_normalization import extract_standard_number
import os
from selenium.webdriver.common.action_chains import ActionChains
import time

def extract_standard_data(standard):
    # Setup Chrome options
    remote_url = os.environ.get("SELENIUM_REMOTE_URL", "http://chrome:4444/wd/hub")
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--enable-javascript")
    options.add_argument("--disable-software-rasterizer")
    options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36")
 

    result = {
        "standard": standard,
        "url": "",
        "extracted": []
    }

    try:
        print("Initializing WebDriver...")
        driver = webdriver.Remote(
            command_executor=remote_url,
            options=options
        )
        wait = WebDriverWait(driver, 30)

        # Wait until the page is fully loaded
        wait.until(lambda driver: driver.execute_script('return document.readyState') == 'complete')

        # Go to the page
        print(f"Navigating to: https://store.accuristech.com/")
        driver.get("https://store.accuristech.com/")

        # Wait for the search input field to become visible
        print("Waiting for search input field...")
        search_input = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "input[type='text'][placeholder*='Search']")))
        print("Search input found, sending search query...")
        search_input.clear()
        search_input.send_keys(standard)
        search_input.send_keys(Keys.RETURN)

        # Wait for clickable result link or handle gracefully
        try:
            print("Waiting for result link to be clickable...")
            result_link = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "a[href^='/searches/']")))
            result_link.click()
        except Exception as e:
            print(f"ℹ️ No Match Found for {standard} (no result link): {e}")
            with open(f"debug_{standard.replace(' ', '_')}_search.html", "w", encoding="utf-8") as f:
                f.write(driver.page_source)
            return result  # Early exit

        # Scroll to the bottom to load any lazy-loaded content
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        result["url"] = driver.current_url

        # Locate product details
        print("Locating product details...")
        items = driver.find_elements(By.CSS_SELECTOR, ".product_detail")

        # Handle no matching product_detail case
        if not items:
            print(f"ℹ️ No Match Found for {standard} (no product details)")
            return result

        # Extract the details from the found items
        print("Extracting data from product details...")
        for item in items:
            lines = item.text.strip().split('\n')
            meta_index = next((i for i, line in enumerate(lines) if line.lower().startswith("standard")), -1)

            pre_meta = lines[:meta_index] if meta_index != -1 else lines
            metadata = " ".join(lines[meta_index:]) if meta_index != -1 else ""

            title = pre_meta[0].strip() if pre_meta else ""
            description = " ".join(pre_meta[1:]) if len(pre_meta) > 1 else ""

            result["extracted"].append({
                "title": title,
                "description": description,
                "metadata": metadata
            })

    except Exception as e:
        print(f"❌ Error extracting data for {standard}: {e}")
        with open(f"debug_{standard.replace(' ', '_')}.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)

    finally:
        print("Closing driver...")
        driver.quit()

    return result

 
def extract_description_for_standard1(standard):
    result = extract_standard_data(standard)
    extracted_entries = result["extracted"]
    
    if not extracted_entries:
        return "No Match Found"

    standard_num=extract_standard_number(standard)
    
    # Exact title match
    for entry in extracted_entries:
        if standard_num == extract_standard_number(entry["title"].strip()):
            return entry["description"]
 
    # Normalized comparison
    norm_input, year_input = extract_standard_number(standard).split(":")
 
    for entry in extracted_entries:
        norm_title, year_title = extract_standard_number(entry["title"]).split(":")
 
        if norm_input == norm_title:
            return entry["description"]
 
        if norm_input.split(":")[0] == norm_title.split(":")[0] and year_input == year_title:
            return entry["description"]
 
    return "No Match Found"

def extract_description_for_standard(standard):
    if ":" not in standard:
        return "Not a Valid Standard"
    
    result = extract_standard_data(standard)
    extracted_entries = result["extracted"]
    
    if not extracted_entries:
        return "No Match Found"

    # standard_num=extract_standard_number(standard)
    # generate_text_file("abc.txt",extracted_entries)
   
    # Exact title match
    for entry in extracted_entries:
        if "This document has been replaced" in entry["description"]:
            continue  # Skip this item
        elif standard.strip() == entry["title"].strip():
            return entry["description"]
        else:
            continue
 
    standard_num=extract_standard_number(standard)
    if standard_num and ":" in standard_num:
        norm_input, year_input = standard_num.split(":",1)
        #norm_title, year_title = result.split(":", 1)
    else:
        print(f"Skipping entry due to not found standard number: {entry['title']}")
        return "No Match Found"
    #norm_input, year_input = extract_standard_number(standard).split(":")
 
    for entry in extracted_entries:
        #norm_title, year_title = extract_standard_number(entry["title"]).split(":")
        st_num=extract_standard_number(entry["title"])
        if st_num and ":" in st_num:
            norm_title, year_title = st_num.split(":",1)
        else:
            print(f"Skipping entry due to not found standard number: {entry['title']}")
            return "No Match Found"
 
        if norm_input == norm_title:
            if "This document has been replaced" in entry["description"]:
                continue  # Skip this item
            return entry["description"]
 
        if norm_input.split(":")[0] == norm_title.split(":")[0] and year_input == year_title:
            return entry["description"]
 
    return "No Match Found"