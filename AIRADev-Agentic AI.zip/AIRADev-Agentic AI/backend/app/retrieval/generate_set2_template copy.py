import openpyxl
from retrieval.questions.question_loader import questions, priority
from .process_question_templates import process_question_templates
from .retrieve_content_template import retrieve_collection_data_template
from retrieval.questions.generate_input_JSON import generate_json_from_master
import json
import logging
import sys
from langchain.globals import set_llm_cache
from langchain_community.cache import InMemoryCache
from collections import defaultdict
from openpyxl.utils import get_column_letter
from openpyxl.cell.cell import Cell
from copy import copy
import ast
import re
from retrieval.Image_comparison.Query_chromadb import store_images_into_remote_chromadb
from retrieval.Image_comparison.load_IFU_data import load_ifu_data


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stdout
)


dict_data = defaultdict(list)
# dict_data.clear()
def query_llama(question, document_id, prompt_template, full_document_search, where_filter, where_document, max_results, pipeline_config):

    llama_response = retrieve_collection_data_template(
        pipeline_config,
        question,
        document_id,
        prompt_template,
        full_document_search,
        where_filter,
        where_document,
        max_results
    )
    return extract_response_array(llama_response)


def extract_response_array(llama_response):
    try:
        # Clean and isolate JSON
        json_start = llama_response.index('{')
        json_data = llama_response[json_start:]
        logging.info(f"json data before: {json_data}")

        # Look for a code block containing a JSON array
        code_block = re.search(r"```(?:json)?\s*(\[.*?\])\s*```", json_data, re.DOTALL)
        if code_block:
            # Extract the JSON array from the code block
            json_data = code_block.group(1)
            logging.info(f"Extracted JSON array from code block: {json_data}")
        # Parse JSON
        data = json.loads(json_data)
        logging.info(f"json data: {data}")

        # Extract and return just the list
        response_list = data.get("response", "")
        logging.info(f"response_list: {response_list}")
        # Make sure it's actually a list
        if isinstance(response_list, list):
            logging.info(f"response data: {response_list}")
            return response_list
        else:
            logging.warning("response is not a list")
            return str(response_list)
    except (ValueError, json.JSONDecodeError, KeyError) as e:
        logging.warning(f"Failed to extract array: {e}")
        return llama_response.strip()  # fallback to list with raw string


def extract_product_code(sheet):
    """Find the cell that contains 'product code' and return the adjacent cell value"""
    for row in sheet.iter_rows():
        for cell in row:
            if cell.value and isinstance(cell.value, str) and "product code" in cell.value.lower():
                adjacent_value = sheet.cell(row=cell.row, column=cell.column + 1).value
                return str(adjacent_value).strip() if adjacent_value else None
    return None

def write_list_to_repeating_rows(sheet, data, start_row, column): 
    for i, item in enumerate(data):
        sheet.cell(row=start_row + i, column=column).value = item

def copy_row_style(template_row, target_row):
    for template_cell, target_cell in zip(template_row, target_row):
        if isinstance(template_cell, Cell) and template_cell.has_style:
            target_cell.font = copy(template_cell.font)
            target_cell.fill = copy(template_cell.fill)
            target_cell.border = copy(template_cell.border)
            target_cell.alignment = copy(template_cell.alignment)
            target_cell.number_format = copy(template_cell.number_format)

    # Copy row height
    target_row_idx = target_row[0].row
    template_row_idx = template_row[0].row
    target_ws = target_row[0].parent
    template_ws = template_row[0].parent

    target_ws.row_dimensions[target_row_idx].height = template_ws.row_dimensions[template_row_idx].height

def apply_styles_by_first_column_match(input_template_path, output_file_path, start_row):
    # Load workbooks
    template_wb = openpyxl.load_workbook(input_template_path)
    output_wb = openpyxl.load_workbook(output_file_path)

    template_ws = template_wb.active
    output_ws = output_wb.active

    # Build map from first cell values in template (starting at row 13)
    template_style_map = {}
    for row in template_ws.iter_rows(min_row=start_row):
        key_cell = row[0]  # Column A
        if key_cell.value:
            key = str(key_cell.value).strip()
            template_style_map[key] = row

    # Apply styles to matching rows in output (starting at row 13)
    for row in output_ws.iter_rows(min_row=start_row):
        key_cell = row[0]  # Column A
        if key_cell.value:
            key = str(key_cell.value).strip()
            if key in template_style_map:
                copy_row_style(template_style_map[key], row)

    output_wb.save(output_file_path)


def form_dict_input(input_type, input_value, column, row, repeat, q_type):
    if q_type == "group" and isinstance(input_value, list):
        input_value = ", ".join(input_value)

    if isinstance(input_value, list):
        for item in input_value:
            if item.strip().lower() == "no trace":
                continue
            found = False
            for entry in dict_data[input_type]:
                if entry["value"] == item:
                    entry["column"].append(column)
                    found = True
                    break
            if not found:
                dict_data[input_type].append({
                    "value": item,
                    "column": [column]
                })

    elif isinstance(input_value, str):
        new_entry = {
            "value": input_value,
            "column": column
        }
        if row is not None:
            new_entry["row"] = row
        if repeat:
            new_entry["repeat"] = repeat
        dict_data[input_type].append(new_entry)

    else:
        print(f"Unsupported data type for {input_type}: {type(input_value)}")

def generate_input_json(
    pipeline_config,
    master_table='Master Input JSON Table',
    group_table='Group Table',
    link_table='Link Table'
):
    questions_dict= generate_json_from_master(
        pipeline_config,
        master_table,
        group_table,
        link_table
    )
    return questions_dict 

def normalize_dict_structure(input_dict):
    normalized = {}
    for key, entries in input_dict.items():
        normalized_entries = []
        for entry in entries:
            normalized_entries.append({
                'value': entry['value'],
                'column_alias_value': entry['column_alias_value'],
                'column': [entry['column']] if isinstance(entry['column'], int) else entry['column'],
                'row': entry['row'],
            })
        normalized[key] = normalized_entries
    return normalized
 
def merge_dicts(dict_1, dict_2):
    for key, entries in dict_2.items():
        if key in dict_1:
            # If the key already exists in dict_1, extend the list of values
            for entry in entries:
                found = False
                # Try to find the same value to merge columns
                for existing_entry in dict_1[key]:
                    if existing_entry['value'].strip().lower() == entry['value'].strip().lower():
                        # Merge columns if the value is the same
                        existing_entry['column'].extend(entry['column'])
                        found = True
                        break
                if not found:
                    dict_1[key].append(entry)
        else:
            # If the key does not exist in dict_1, simply add it
            dict_1[key] = entries

    return dict_1

def merge_dicts2(dict_1, dict_2):
    for key, entries in dict_2.items():
        if key in dict_1:
            # If the key already exists in dict_1, extend the list of values
            for entry in entries:
                found = False
                # Try to find the same value to merge columns
                for existing_entry in dict_1[key]:
                    if existing_entry['column_alias_value'].strip().lower() == entry['value'].strip().lower():
                        # Merge columns if the value is the same
                        existing_entry['column'].extend(entry['column'])
                        found = True
                        break
                if not found:
                    dict_1[key].append(entry)
        else:
            # If the key does not exist in dict_1, simply add it
            dict_1[key] = entries

    return dict_1


dict_data = defaultdict(list)

def generate_set2_template(input_file_path, output_file_path, pipeline_config):
    global dict_data
    dict_data.clear()
    
    # Set InMemoryCache as the global LLM cache
    set_llm_cache(InMemoryCache())

    # logging.info(f"generate output template")
    # Load workbook and sheet    
    workbook = openpyxl.load_workbook(input_file_path)
    sheet = workbook.active

    priority_list = priority()
    # Step 1: Extract product code
    product_code = extract_product_code(sheet)
    if not product_code:
        return
            
    # Step 2: Generate question templates
    process_question_templates(
        questions_fn=generate_input_json,                      
        product_code=product_code,                   
        form_dict_input_fn=form_dict_input,          
        query_llama_fn=query_llama,                 
        dict_data=dict_data,                        
        config=pipeline_config
    )

    logging.info(f"priority:{priority_list}")
    dict_2 = json.loads(load_ifu_data())
    normalized_dict_2 = normalize_dict_structure(dict_2)
    logging.info(f"dict_2: {normalized_dict_2}")

    dict_3 = json.loads(store_images_into_remote_chromadb())
    logging.info(f"dict_3: {dict_3}")
    # dict_data = merge_dicts(dict_data, dict_2)
    
    dict_merge_data = merge_dicts2(normalized_dict_2, dict_3)
    dict_data = merge_dicts(dict_data, dict_merge_data)
    logging.info(f"merged_dict_data: {dict_data}")
    for item in priority_list:
        entries = dict_data.get(item, [])

        for i, entry in enumerate(entries):
            column = entry.get("column")
            value = entry.get("value")
            row = entry.get("row", None)
            repeat = entry.get("repeat", None)
            # Case 1: Specific row and column are defined
            if row is not None and column is not None:
                if isinstance(column, list):
                    for col in column:
                        sheet.cell(row=row, column=col).value = value
                else:
                    cell = sheet.cell(row=row, column=column)
                    if item == "Section_Number":
                        if cell.value and value not in str(cell.value):
                            cell.value = str(cell.value).strip() + f", {value}"
                    else:
                        sheet.cell(row=row, column=column).value = value
                
                #sheet.cell(row=row, column=1).value = item  # optional: set item as header
                # ✅ Only set column 1 if not already populated
                col1 = sheet.cell(row=row, column=1)
                if col1.value is None or str(col1.value).strip() == "":
                    col1.value = item

            # Case 2: Repeat value for each row in range
            elif repeat == "Yes" and column is not None:
                if isinstance(column, list):
                    for row_idx in range(13, sheet.max_row + 1):
                        for col in column:
                            cell = sheet.cell(row=row_idx, column=col)
                            if cell.value is None or str(cell.value).strip() == "":
                                sheet.cell(row=row_idx, column=col).value = value
                                sheet.cell(row=row_idx, column=1).value = item
                else:
                    for row_idx in range(13, sheet.max_row + 1):
                        sheet.cell(row=row_idx, column=column).value = value

            # Case 3: Insert into next available row
            elif isinstance(column, list):
                next_row = get_next_empty_row(sheet, start=13)
                for col in column:
                    sheet.cell(row=next_row, column=col).value = value
                sheet.cell(row=next_row, column=1).value = item  # insert row label

            # Case 4: Unknown configuration - log and skip
            else:
                logging.info(f"Skipping entry at index {i}: row={row}, column={column}, value={value}, repeat={repeat}")

            
    
    for row in sheet.iter_rows(min_row=13, max_row=sheet.max_row, max_col=sheet.max_column):
        for cell in row:
            if cell.column == 2:
                cell.value = product_code
            elif cell.value is None or str(cell.value).strip() == "":
                cell.value = "No Trace"
    
    # Save updated workbook
    workbook.save(output_file_path)
    apply_styles_by_first_column_match(input_file_path, output_file_path, start_row=13)
    set2_conversion_logic(output_file_path, start_row=13)
    logging.info(f"Done! Output saved to: {output_file_path}")

def get_next_empty_row(sheet, start):
    """Finds the first completely empty row starting from a given row."""
    row = start
    while True:
        if all(sheet.cell(row=row, column=col).value is None for col in range(3, sheet.max_column + 1)):
            return row
        row += 1

def set2_conversion_logic(output_file_path, start_row=13):
    # Constants
    con_wb = openpyxl.load_workbook(output_file_path)

    con_ws = con_wb.active

    aj_column = 36  # AJ
    ai_column = 35  # AI
    description_columns = []

    # Step 1: Identify "Description / Content" columns and map to product names

    col = 3  
    while col <= 34: 
        header_12 = con_ws.cell(row=12, column=col + 1).value  
        if header_12 and "Description / Content" in str(header_12):
            product_name = con_ws.cell(row=11, column=col).value 
            description_columns.append((col + 1, product_name))
        col += 2  # Move to next product block (2 columns per product)

    # Step 2: Loop through each data row

    for row in range(start_row, con_ws.max_row + 1):
        matching_products = []
        found_no_trace = False

        for col_index in range(3, 35): 
            cell_value = con_ws.cell(row=row, column=col_index).value
            if isinstance(cell_value, str) and "No Trace" in cell_value:
                found_no_trace = True

        for col_index, product in description_columns:
            cell_value = con_ws.cell(row=row, column=col_index).value
            if isinstance(cell_value, str) and "No Trace" in cell_value:
                matching_products.append(product)

        if found_no_trace:
            con_ws.cell(row=row, column=ai_column).value = "N"
        if matching_products:
            con_ws.cell(row=row, column=aj_column).value = ", ".join(matching_products)
    con_wb.save(output_file_path)

