# backend/app/upload_agent_graph.py
import os
import logging
from dataclasses import dataclass, field
from langgraph.graph import StateGraph, END

from documents_ingestion.load_documents import load_documents
from documents_ingestion.chunker import generate_all_chunks
from documents_ingestion.embedder import embed_chunks_with_dynamic_backend
from documents_ingestion.vectorizer import document_vectorize_by_section
from documents_ingestion.move_files_to_archive import move_files_to_archive
from documents_ingestion.remove_empty_folders import remove_empty_folders
from config.config_loader import ConfigLoader
from config.model_factory import get_llm_and_embedder

logging.basicConfig(level=logging.INFO)

# Initialize config and embeddings
config_loader = ConfigLoader()
llm, embedder = get_llm_and_embedder(config_loader)

pipeline_config = {
    "embedder": embedder,
    "llm": llm,
    "chroma_host": config_loader.get("storage", "chroma", "host"),
    "chroma_port": config_loader.get("storage", "chroma", "port"),
    "collection": config_loader.get("storage", "chroma", "collection_name"),
    "upload_folder": config_loader.get("data", "upload_folder"),
    "archive_folder": config_loader.get("data", "archive_folder"),
}

@dataclass
class UploadState:
    folder_path: str
    documents: list = field(default_factory=list)
    chunks: list = field(default_factory=list)
    embeddings: list = field(default_factory=list)
    valid_chunks: list = field(default_factory=list)
    vector_status: str = ""

# --- Agent Steps ---

def load_docs(state: UploadState):
    folder = state.folder_path
    logging.info(f"Step 1: Loading documents from {folder}")
    state.documents = load_documents(folder)
    return state

def chunk_docs(state: UploadState):
    logging.info("Step 2: Generating chunks...")
    state.chunks = generate_all_chunks(state.documents)
    return state

def embed_docs(state: UploadState):
    logging.info("Step 3: Embedding chunks...")
    embeddings, valid_chunks = embed_chunks_with_dynamic_backend(state.chunks, config_loader)
    state.embeddings = embeddings
    state.valid_chunks = valid_chunks
    return state

def vectorize_docs(state: UploadState):
    logging.info("Step 4: Vectorizing documents in Chroma...")
    if state.valid_chunks and state.embeddings:
        resp = document_vectorize_by_section(
            pipeline_config["chroma_host"],
            pipeline_config["chroma_port"],
            pipeline_config["collection"],
            state.valid_chunks,
            state.embeddings
        )
        state.vector_status = resp.get("status", "success")
    else:
        state.vector_status = "No valid embeddings/chunks"
    return state

def archive_and_cleanup(state: UploadState):
    logging.info("Step 5: Archiving and cleaning folders...")
    move_files_to_archive(pipeline_config["upload_folder"], pipeline_config["archive_folder"])
    remove_empty_folders(pipeline_config["upload_folder"])
    return state

# --- Build LangGraph ---
graph = StateGraph(UploadState)

graph.add_node("load_docs", load_docs)
graph.add_node("chunk_docs", chunk_docs)
graph.add_node("embed_docs", embed_docs)
graph.add_node("vectorize_docs", vectorize_docs)
graph.add_node("archive_and_cleanup", archive_and_cleanup)

graph.set_entry_point("load_docs")
graph.add_edge("load_docs", "chunk_docs")
graph.add_edge("chunk_docs", "embed_docs")
graph.add_edge("embed_docs", "vectorize_docs")
graph.add_edge("vectorize_docs", "archive_and_cleanup")
graph.add_edge("archive_and_cleanup", END)

upload_agent = graph.compile()
