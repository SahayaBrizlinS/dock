from rag_pipeline.embeddings.ollama_embed import OllamaEmbedder
from rag_pipeline.embeddings.openai_embed import OpenAIEmbedder
from rag_pipeline.embeddings.azure_openai_embed import AzureOpenAIEmbedder

from rag_pipeline.llms.ollama_llm import OllamaLLM
from rag_pipeline.llms.openai_llm import OpenAILLM
from rag_pipeline.llms.azure_openai_llm import AzureOpenAILLM

def get_llm_and_embedder(config):
    backend = config.get("embeddings", "backend")

    if backend == "ollama":
        embedder = OllamaEmbedder(
            model=config.get("embeddings", "ollama", "model"),
            base_url=config.get("embeddings", "ollama", "base_url")
        )
        llm = OllamaLLM(
            model=config.get("llms", "ollama", "model"),
            base_url=config.get("embeddings", "ollama", "base_url")
        )

    elif backend == "openai":
        embedder = OpenAIEmbedder(
            model=config.get("embeddings", "openai", "model"),
            api_key=config.get("llms", "openai", "api_key"),
            base_url=config.get("embeddings", "openai", "base_url"),
            api_version=config.get("embeddings", "openai", "model_version")
        )
        llm = OpenAILLM(
            model=config.get("llms", "openai", "model"),
            api_key=config.get("llms", "openai", "api_key"),
            api_base=config.get("llms", "openai", "base_url"),
            api_version=config.get("llms", "openai", "api_version"),
            deployment_name=config.get("llms", "openai", "azure_deployment_name")
        )

    elif backend == "azure":
        embedder = AzureOpenAIEmbedder(
            model=config.get("embeddings", "azure", "model"),
            api_key=config.get("embeddings", "azure", "api_key"),
            base_url=config.get("embeddings", "azure", "base_url"),
            deployment_name=config.get("embeddings", "azure", "deployment_name"),
            model_version=config.get("embeddings", "azure", "model_version"),
            api_type=config.get("embeddings", "azure", "api_type")
        )
        llm = AzureOpenAILLM(
            model=config.get("llms", "azure", "model"),
            api_key=config.get("llms", "azure", "api_key"),
            base_url=config.get("llms", "azure", "base_url"),
            deployment_name=config.get("llms", "azure", "deployment_name"),
            model_version=config.get("llms", "azure", "model_version"),
            api_type=config.get("llms", "azure", "api_type")
        )

    else:
        raise ValueError(f"Unsupported embedding backend: {backend}")

    return llm, embedder
