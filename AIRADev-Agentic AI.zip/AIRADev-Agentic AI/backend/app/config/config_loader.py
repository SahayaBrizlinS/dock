import os
import yaml

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.yaml")
class ConfigLoader:
    def __init__(self, config_path=CONFIG_PATH):
        self.config_path = config_path
        self.config = self._load()

    def _load(self):
        with open(self.config_path, "r") as f:
            return yaml.safe_load(f)

    def get(self, *keys, default=None):
        cfg = self.config
        for key in keys:
            if key in cfg:
                cfg = cfg[key]
            else:
                return default
        return cfg

