import json

# Function to load and append data
def load_and_append_json(file_path, target_dict):
    # Load the JSON data from the file
    with open(file_path, 'r') as file:
        json_data = json.load(file)

    # Append 'Claims', 'Warnings', and 'Cautions' to the target dictionary
    target_dict['Claims'] = json_data.get('Claims', [])
    target_dict['Warnings'] = json_data.get('Warnings', [])
    target_dict['Cautions'] = json_data.get('Cautions', [])
    
    return target_dict

# Example of the target dictionary to append data
target_dict = {
    'Claims': [],
    'Warnings': [],
    'Cautions': []
}

# Define the path to the JSON file (replace this with your actual file path)
file_path = 'IFU_Data.json'

# Call the function to load and append the data
target_dict = load_and_append_json(file_path, target_dict)

# Print the updated target dictionary
print(json.dumps(target_dict, indent=2))
