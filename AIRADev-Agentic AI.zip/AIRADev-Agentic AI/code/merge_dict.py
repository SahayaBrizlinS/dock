def merge_in_place(dict_1, dict_2):
    # Iterate through the keys of dict_2
    for key in dict_2:
        if key in dict_1:
            # If key already exists in dict_1, extend the list with items from dict_2
            dict_1[key].extend(dict_2[key])
        else:
            # If the key does not exist in dict_1, add the key and its values from dict_2
            dict_1[key] = dict_2[key]
    return dict_1

# Example data
dict_data_2 = {
    "Cautions": [
        {
            "value": "Do not use if package is damaged and consult instructions for use",
            "columns": [6, 8]
        },
        {
            "value": "Do Not Reuse",
            "columns": [6, 8]
        },
        {
            "value": "Do Not Resterilize",
            "columns": [6, 8]
        }
    ]
}

dict_data_1 = {
    "Date": [
        {
            "value": "0719004306_IFU, Not found, 04-DEC-2024",
            "column": 3,
            "repeat": "Yes"
        },
        {
            "value": "BXU601670_MDR_CER, Rev A, 19-Dec-2024, Sec 5.1",
            "column": 9,
            "row": 13,
            "repeat": "No"
        }
    ]
}

# Merge dict_2 into dict_1
merged_data = merge_in_place(dict_data_1, dict_data_2)

# Output the result
print(merged_data)
