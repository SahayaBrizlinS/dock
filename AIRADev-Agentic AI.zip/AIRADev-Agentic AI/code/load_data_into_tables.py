import pandas as pd
import psycopg2
import json

def create_table_from_sheet(excel_path, sheet_name, table_name, db_config):
    df = pd.read_excel(excel_path, sheet_name=sheet_name)
    df.columns = df.columns.astype(str)

    conn = psycopg2.connect(**db_config)
    cur = conn.cursor()

    # Truncate the table if it already exists
    truncate_query = f'TRUNCATE TABLE "{table_name}" RESTART IDENTITY CASCADE;'
    try:
        cur.execute(truncate_query)
    except psycopg2.errors.UndefinedTable:
        # If the table does not exist yet, it's fine – we will create it next
        conn.rollback()

    # Create table if it doesn't exist
    columns = df.columns
    escaped_columns = [f'"{col}"' for col in columns]
    col_defs = ', '.join([f'"{col}" TEXT' for col in columns])
    create_query = f'CREATE TABLE IF NOT EXISTS "{table_name}" ({col_defs});'
    cur.execute(create_query)

    # Insert rows
    for _, row in df.iterrows():
        values = [str(v) if pd.notnull(v) else None for v in row]
        placeholders = ', '.join(['%s'] * len(values))
        insert_query = f'INSERT INTO "{table_name}" ({", ".join(escaped_columns)}) VALUES ({placeholders});'
        cur.execute(insert_query, values)

    conn.commit()
    cur.close()
    conn.close()
    print(f"✅ Table '{table_name}' created from sheet '{sheet_name}'")

# Excel path and DB config
excel_path = 'InputJSON-Set2-updated.xlsx'
db_config = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'airadb',
    'user': 'airadev',
    'password': 'Password123'
}

# Create tables from Excel sheets
create_table_from_sheet(excel_path, 'Input JSON', 'Master Input JSON Table', db_config)
create_table_from_sheet(excel_path, 'Group Table', 'Group Table', db_config)
create_table_from_sheet(excel_path, 'Link Table', 'Link Table', db_config)
