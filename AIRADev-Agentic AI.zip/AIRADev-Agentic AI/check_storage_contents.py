import os
import sys

def scan_directory(base_path):
    print(f"\n🔍 Scanning folder: {base_path}\n")

    found = {
        "pdfs": [],
        "csvs": [],
        "jsons": [],
        "pkls": [],
        "chroma": [],
    }

    for root, dirs, files in os.walk(base_path):
        for file in files:
            if file.lower().endswith(".pdf"):
                found["pdfs"].append(os.path.join(root, file))
            elif file.lower().endswith(".csv"):
                found["csvs"].append(os.path.join(root, file))
            elif file.lower().endswith(".json"):
                found["jsons"].append(os.path.join(root, file))
            elif file.lower().endswith(".pkl"):
                found["pkls"].append(os.path.join(root, file))

        for d in dirs:
            if "chroma" in d.lower() or "chromadb" in d.lower():
                found["chroma"].append(os.path.join(root, d))

    for category, paths in found.items():
        print(f"\n🗂 {category.upper()} FOUND ({len(paths)}):")
        for path in paths:
            print("   ✅", path)

if __name__ == "__main__":
    path_to_scan = sys.argv[1] if len(sys.argv) > 1 else "."
    scan_directory(path_to_scan)
