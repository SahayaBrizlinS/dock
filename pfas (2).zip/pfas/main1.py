# main.py
from fastapi import FastAPI, UploadFile, Form, HTTPException, Depends, Query
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, FileResponse
from sqlalchemy import create_engine, Column, String, Boolean, Numeric, Integer
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from io import BytesIO
import pandas as pd
from openpyxl.styles import PatternFill
import logging
from typing import List, Optional
import os

# ======================
# Database Config (like your Flask code)
# ======================
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "PFAS_1")

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pfas_app")

# ======================
# DATABASE MODELS
# ======================
class PFASBOM(Base):
    __tablename__ = "pfas_bom"
    sku = Column(String(100), primary_key=True)
    component = Column(String(100), primary_key=True)
    subcomponent = Column(String(100), primary_key=True)
    material = Column(String(100), primary_key=True)
    product = Column(String(100), nullable=False)
    component_description = Column(String(100), nullable=False)
    subcomponent_description = Column(String(100), nullable=False)
    material_name = Column(String(100), nullable=False)
    portal_name = Column(String(100), nullable=False)
    region = Column(String(100))
    assessment = Column(String(100))
    flag = Column(Boolean, default=False, nullable=False)

class PFASMaterialChemicals(Base):
    __tablename__ = "result"
    material_id = Column(String(100), primary_key=True)
    cas_number = Column(String(255))
    material_name = Column(String(100))
    chemical_name = Column(String(500))
    concentration_ppm = Column(Numeric(10, 4))
    supplier_name = Column(String(255))
    reference = Column(String(255))

class PFASRegulations(Base):
    __tablename__ = "pfas_regulations"
    cas_number = Column(String(255), primary_key=True)
    chemical_name = Column(String(500))
    molecular_formula = Column(String(255))
    structure_category_name = Column(String(255))
    australian_aics = Column(Integer)
    australian_imap_tier_2 = Column(Integer)
    canadian_dsl = Column(Integer)
    canada_pctsr_2012 = Column(Integer)
    eu_reach_pre_registered = Column(Integer)
    eu_reach_registered_ppm = Column(Integer)
    us_epa_tscainventory = Column(Integer)
    us_epa_tsca12b = Column(Integer)

Base.metadata.create_all(bind=engine)

# ======================
# FASTAPI APP
# ======================
app = FastAPI(title="PFAS Management System")

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ======================
# ROUTES
# ======================

@app.get("/", response_class=HTMLResponse)
def index(db: Session = Depends(get_db)):
    try:
        results = db.query(
            PFASBOM.sku, PFASBOM.product, PFASBOM.portal_name, PFASBOM.region, PFASBOM.assessment
        ).distinct(PFASBOM.sku).all()

        products = [
            {
                "sku": r.sku,
                "product_name": f"{r.sku}_{r.product}",
                "portal_name": r.portal_name,
                "region": r.region or "Global",
                "assessment": r.assessment or "PFAS"
            }
            for r in results
        ]
        html_content = f"<h1>Products ({len(products)})</h1><pre>{products}</pre>"
        return HTMLResponse(html_content)
    except Exception as e:
        logger.error(f"Error loading index: {e}", exc_info=True)
        return HTMLResponse("<h1>Error loading products</h1>")

@app.get("/filter", response_class=HTMLResponse)
def filter_page():
    return HTMLResponse("<h1>Filter Page</h1>")

# ----------------------
# Upload BOM
# ----------------------
@app.post("/upload")
async def upload_bom(
    file: UploadFile,
    regions: List[str] = Form([]),
    assessments: List[str] = Form([]),
    db: Session = Depends(get_db)
):
    if not file:
        raise HTTPException(status_code=400, detail="No file uploaded")
    
    portal_name = "SAP"
    region_str = ",".join(regions) or "Global"
    assessment_str = ",".join(assessments) or "PFAS"

    try:
        data = await file.read()
        buf = BytesIO(data)
        fname = file.filename.lower()
        if fname.endswith(".csv"):
            df = pd.read_csv(buf, dtype=str)
        elif fname.endswith((".xlsx", ".xls")):
            df = pd.read_excel(buf, sheet_name=0, dtype=str)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        df.columns = [str(c).strip().replace("\n","").replace("\r","").replace(" ","_").lower() for c in df.columns]

        required_cols = {
            'sku':['sku','product_id','part_number'],
            'product':['product','product_name','product_desc'],
            'component':['component','comp','component_id'],
            'component_description':['component_description','comp_desc','component_desc'],
            'subcomponent':['subcomponent','sub_comp','subcomponent_id'],
            'subcomponent_description':['subcomponent_description','sub_comp_desc','subcomponent_desc'],
            'material':['material','mat_id','material_id'],
            'material_name':['material_name','mat_name','material_desc']
        }

        col_map = {}
        for target, options in required_cols.items():
            found = next((o for o in options if o in df.columns), None)
            if not found:
                raise HTTPException(status_code=400, detail=f"Missing column {target}")
            col_map[target] = found

        inserted, updated, skipped = 0,0,0
        for idx, row in df.iterrows():
            try:
                sku_val = str(row[col_map['sku']]).strip().split('.')[0]
                product_val = str(row[col_map['product']]).strip()
                material_val = str(row[col_map['material']]).strip().split('.')[0]
                if not all([sku_val, product_val, material_val]) or 'nan' in [sku_val, material_val]:
                    skipped +=1
                    continue
                
                existing = db.query(PFASBOM).filter_by(sku=sku_val, material=material_val).first()
                if existing:
                    existing.product = product_val
                    existing.component = str(row[col_map['component']]).strip().split('.')[0]
                    existing.component_description = str(row[col_map['component_description']]).strip()
                    existing.subcomponent = str(row[col_map['subcomponent']]).strip()
                    existing.subcomponent_description = str(row[col_map['subcomponent_description']]).strip()
                    existing.material_name = str(row[col_map['material_name']]).strip()
                    existing.portal_name = portal_name
                    existing.region = region_str
                    existing.assessment = assessment_str
                    updated += 1
                else:
                    new_row = PFASBOM(
                        sku=sku_val,
                        product=product_val,
                        component=str(row[col_map['component']]).strip().split('.')[0],
                        component_description=str(row[col_map['component_description']]).strip(),
                        subcomponent=str(row[col_map['subcomponent']]).strip(),
                        subcomponent_description=str(row[col_map['subcomponent_description']]).strip(),
                        material=material_val,
                        material_name=str(row[col_map['material_name']]).strip(),
                        portal_name=portal_name,
                        region=region_str,
                        assessment=assessment_str
                    )
                    db.add(new_row)
                    inserted += 1
            except Exception as e:
                logger.error(f"Row {idx} skipped: {e}")
                skipped += 1
        db.commit()
        return JSONResponse({"inserted": inserted, "updated": updated, "skipped": skipped})
    except Exception as e:
        db.rollback()
        logger.error(f"Upload failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Upload failed")

# ----------------------
# PFAS Assessment API
# ----------------------
@app.get("/api/pfas-assessment/{sku}")
def pfas_assessment(sku: str, db: Session = Depends(get_db)):
    bom_rows = db.query(PFASBOM).filter_by(sku=sku).all()
    if not bom_rows:
        raise HTTPException(status_code=404, detail="SKU not found")

    product_name = f"{bom_rows[0].sku}_{bom_rows[0].product}"
    materials = [r.material for r in bom_rows]

    try:
        results = db.query(
            PFASBOM.component,
            PFASBOM.subcomponent,
            PFASBOM.material,
            PFASBOM.material_name,
            PFASMaterialChemicals.cas_number,
            PFASMaterialChemicals.chemical_name,
            PFASMaterialChemicals.concentration_ppm,
            PFASMaterialChemicals.supplier_name,
            PFASRegulations.australian_aics,
            PFASRegulations.australian_imap_tier_2,
            PFASRegulations.canadian_dsl,
            PFASRegulations.canada_pctsr_2012,
            PFASRegulations.eu_reach_pre_registered,
            PFASRegulations.eu_reach_registered_ppm,
            PFASRegulations.us_epa_tscainventory,
            PFASRegulations.us_epa_tsca12b
        ).join(PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id)\
         .outerjoin(PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number)\
         .filter(PFASBOM.sku == sku).all()
    except Exception as e:
        logger.error(f"Join failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to retrieve data")

    if not results:
        return JSONResponse({"product": product_name, "summary":{"total":0,"non_conforming":0,"in_conformance":0}, "data":[]})

    regulations = [
        {'name':'Australian AICS','col':'australian_aics'},
        {'name':'Australian IMAP Tier 2','col':'australian_imap_tier_2'},
        {'name':'Canadian DSL','col':'canadian_dsl'},
        {'name':'Canada PCTSR 2012','col':'canada_pctsr_2012'},
        {'name':'EU REACH Pre Registered','col':'eu_reach_pre_registered'},
        {'name':'EU REACH Registered','col':'eu_reach_registered_ppm'},
        {'name':'US EPA TSCA Inventory','col':'us_epa_tscainventory'},
        {'name':'US EPA TSCA 12B','col':'us_epa_tsca12b'}
    ]

    data = []
    non_conforming_count = 0

    for row in results:
        conc = float(row.concentration_ppm) if row.concentration_ppm else 0.0
        limits = []
        is_non_conforming = False

        for reg in regulations:
            value = getattr(row, reg['col'], None)
            if value is None:
                continue
            threshold = float(value)
            if conc > threshold:
                status = "exceeded"
                is_non_conforming = True
            else:
                status = "within"
            limits.append({"name":reg['name'], "limit":f"{threshold} ppm", "status":status})

        if is_non_conforming:
            non_conforming_count +=1

        data.append({
            "component": row.component or "-",
            "subcomponent": row.subcomponent or "-",
            "material": row.material or "-",
            "material_name": row.material_name or "-",
            "supplier_name": row.supplier_name or "-",
            "chemical_name": row.chemical_name or "Unknown",
            "cas_number": row.cas_number or "Unknown",
            "concentration": f"{conc:.2f} ppm",
            "limits": limits,
            "status": "Non-Conforming" if is_non_conforming else "Conforming",
            "status_color": "danger" if is_non_conforming else "success"
        })
    return JSONResponse({
        "product": product_name,
        "summary":{"total":len(data),"non_conforming":non_conforming_count,"in_conformance":len(data)-non_conforming_count},
        "data": data
    })

# ----------------------
# Download BOM
# ----------------------
@app.get("/download-bom/{sku}")
def download_bom(sku: str, db: Session = Depends(get_db)):
    bom_data = db.query(PFASBOM).filter_by(sku=sku).all()
    if not bom_data:
        raise HTTPException(status_code=404, detail="No BOM data found")

    rows = [{
        "SKU": r.sku,
        "Product": r.product,
        "Component": r.component,
        "Component Description": r.component_description,
        "Sub-Component": r.subcomponent,
        "Sub-Component Description": r.subcomponent_description,
        "Material": r.material,
        "Material Name": r.material_name,
        "Portal Name": r.portal_name,
        "Region": r.region,
        "Assessment": r.assessment
    } for r in bom_data]

    df = pd.DataFrame(rows)
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="BOM Details", index=False)
    buf.seek(0)

    filename = f"BOM_{sku}.xlsx"
    return FileResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename=filename)

# ----------------------
# DELETE Product
# ----------------------
@app.delete("/api/delete-product/{sku}")
def delete_product(sku: str, db: Session = Depends(get_db)):
    entries = db.query(PFASBOM).filter_by(sku=sku).all()
    if not entries:
        raise HTTPException(status_code=404, detail="Product not found")
    deleted_count = db.query(PFASBOM).filter_by(sku=sku).delete()
    db.commit()
    return JSONResponse({"success":True, "message":f"Deleted {deleted_count} entries", "sku":sku})

# ======================
# FILTER / COMPONENT / MATERIAL API
# ======================

@app.get("/api/skus")
def get_skus(db: Session = Depends(get_db)):
    results = db.query(PFASBOM.sku, PFASBOM.product).distinct(PFASBOM.sku).all()
    data = [f"{r.sku} - {r.product}" for r in results]
    return JSONResponse({"skus": data})

@app.get("/api/components")
def get_components(skus: str = Query(None), db: Session = Depends(get_db)):
    if not skus:
        return JSONResponse({"components":[]})
    sku_list = [s.split(" - ")[0] for s in skus.split(",")]
    results = db.query(PFASBOM.component, PFASBOM.component_description).filter(PFASBOM.sku.in_(sku_list)).distinct().all()
    data = [f"{r.component} - {r.component_description}" for r in results]
    return JSONResponse({"components": data})

@app.get("/api/subcomponents")
def get_subcomponents(
    skus: str = Query(None),
    components: str = Query(None),
    db: Session = Depends(get_db)
):
    if not skus or not components:
        return JSONResponse({"subcomponents":[]})
    sku_list = [s.split(" - ")[0] for s in skus.split(",")]
    comp_list = [c.split(" - ")[0] for c in components.split(",")]
    results = db.query(PFASBOM.subcomponent, PFASBOM.subcomponent_description)\
        .filter(PFASBOM.sku.in_(sku_list), PFASBOM.component.in_(comp_list))\
        .distinct().all()
    data = [f"{r.subcomponent} - {r.subcomponent_description}" for r in results]
    return JSONResponse({"subcomponents": data})

@app.get("/api/materials")
def get_materials(
    skus: str = Query(None),
    components: str = Query(None),
    subcomponents: str = Query(None),
    db: Session = Depends(get_db)
):
    if not all([skus, components, subcomponents]):
        return JSONResponse({"materials":[]})
    sku_list = [s.split(" - ")[0] for s in skus.split(",")]
    comp_list = [c.split(" - ")[0] for c in components.split(",")]
    sub_list = [s.split(" - ")[0] for s in subcomponents.split(",")]
    results = db.query(PFASBOM.material, PFASBOM.material_name)\
        .filter(PFASBOM.sku.in_(sku_list), PFASBOM.component.in_(comp_list), PFASBOM.subcomponent.in_(sub_list))\
        .distinct().all()
    data = [f"{r.material} - {r.material_name}" for r in results]
    return JSONResponse({"materials": data})

# ===================================================
# Remaining Filter Results, Export, PFAS Report endpoints
# ===================================================
# ======================
# FILTER RESULTS API
# ======================
@app.get("/api/filter-results")
def filter_results(
    skus: Optional[str] = Query(None),
    components: Optional[str] = Query(None),
    subcomponents: Optional[str] = Query(None),
    materials: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    query = db.query(PFASBOM)
    
    if skus:
        sku_list = [s.split(" - ")[0] for s in skus.split(",")]
        query = query.filter(PFASBOM.sku.in_(sku_list))
    if components:
        comp_list = [c.split(" - ")[0] for c in components.split(",")]
        query = query.filter(PFASBOM.component.in_(comp_list))
    if subcomponents:
        sub_list = [s.split(" - ")[0] for s in subcomponents.split(",")]
        query = query.filter(PFASBOM.subcomponent.in_(sub_list))
    if materials:
        mat_list = [m.split(" - ")[0] for m in materials.split(",")]
        query = query.filter(PFASBOM.material.in_(mat_list))
    
    results = query.all()
    data = [{
        "sku": r.sku,
        "product": r.product,
        "component": r.component,
        "component_description": r.component_description,
        "subcomponent": r.subcomponent,
        "subcomponent_description": r.subcomponent_description,
        "material": r.material,
        "material_name": r.material_name,
        "portal_name": r.portal_name,
        "region": r.region,
        "assessment": r.assessment
    } for r in results]
    
    return JSONResponse({"count": len(data), "results": data})

# ======================
# EXPORT FILTER RESULTS TO EXCEL
# ======================
@app.get("/export/filter-results")
def export_filter_results(
    skus: Optional[str] = Query(None),
    components: Optional[str] = Query(None),
    subcomponents: Optional[str] = Query(None),
    materials: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    query = db.query(PFASBOM)
    
    if skus:
        sku_list = [s.split(" - ")[0] for s in skus.split(",")]
        query = query.filter(PFASBOM.sku.in_(sku_list))
    if components:
        comp_list = [c.split(" - ")[0] for c in components.split(",")]
        query = query.filter(PFASBOM.component.in_(comp_list))
    if subcomponents:
        sub_list = [s.split(" - ")[0] for s in subcomponents.split(",")]
        query = query.filter(PFASBOM.subcomponent.in_(sub_list))
    if materials:
        mat_list = [m.split(" - ")[0] for m in materials.split(",")]
        query = query.filter(PFASBOM.material.in_(mat_list))
    
    results = query.all()
    
    if not results:
        raise HTTPException(status_code=404, detail="No data to export")
    
    df = pd.DataFrame([{
        "SKU": r.sku,
        "Product": r.product,
        "Component": r.component,
        "Component Description": r.component_description,
        "Sub-Component": r.subcomponent,
        "Sub-Component Description": r.subcomponent_description,
        "Material": r.material,
        "Material Name": r.material_name,
        "Portal Name": r.portal_name,
        "Region": r.region,
        "Assessment": r.assessment
    } for r in results])
    
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Filter Results", index=False)
        worksheet = writer.sheets["Filter Results"]
        # Optional styling
        for col in worksheet.columns:
            max_length = max(len(str(cell.value)) for cell in col)
            col_letter = col[0].column_letter
            worksheet.column_dimensions[col_letter].width = max_length + 2
    
    buf.seek(0)
    return FileResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        filename="filter_results.xlsx")

# ======================
# PFAS REPORT EXPORT TO EXCEL
# ======================
@app.get("/export/pfas-report/{sku}")
def export_pfas_report(sku: str, db: Session = Depends(get_db)):
    # Get assessment data
    bom_rows = db.query(PFASBOM).filter_by(sku=sku).all()
    if not bom_rows:
        raise HTTPException(status_code=404, detail="SKU not found")

    results = db.query(
        PFASBOM.component,
        PFASBOM.subcomponent,
        PFASBOM.material,
        PFASBOM.material_name,
        PFASMaterialChemicals.cas_number,
        PFASMaterialChemicals.chemical_name,
        PFASMaterialChemicals.concentration_ppm,
        PFASMaterialChemicals.supplier_name,
        PFASRegulations.australian_aics,
        PFASRegulations.australian_imap_tier_2,
        PFASRegulations.canadian_dsl,
        PFASRegulations.canada_pctsr_2012,
        PFASRegulations.eu_reach_pre_registered,
        PFASRegulations.eu_reach_registered_ppm,
        PFASRegulations.us_epa_tscainventory,
        PFASRegulations.us_epa_tsca12b
    ).join(PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id)\
     .outerjoin(PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number)\
     .filter(PFASBOM.sku == sku).all()

    if not results:
        raise HTTPException(status_code=404, detail="No PFAS data found for this SKU")

    regulations = [
        ('Australian AICS', 'australian_aics'),
        ('Australian IMAP Tier 2', 'australian_imap_tier_2'),
        ('Canadian DSL', 'canadian_dsl'),
        ('Canada PCTSR 2012', 'canada_pctsr_2012'),
        ('EU REACH Pre Registered', 'eu_reach_pre_registered'),
        ('EU REACH Registered', 'eu_reach_registered_ppm'),
        ('US EPA TSCA Inventory', 'us_epa_tscainventory'),
        ('US EPA TSCA 12B', 'us_epa_tsca12b')
    ]

    export_rows = []
    for r in results:
        conc = float(r.concentration_ppm) if r.concentration_ppm else 0.0
        row_data = {
            "Component": r.component,
            "Subcomponent": r.subcomponent,
            "Material": r.material,
            "Material Name": r.material_name,
            "Supplier Name": r.supplier_name,
            "Chemical Name": r.chemical_name,
            "CAS Number": r.cas_number,
            "Concentration (ppm)": conc
        }
        for reg_name, col_name in regulations:
            limit = getattr(r, col_name)
            if limit is not None:
                row_data[reg_name] = f"{limit} ppm"
            else:
                row_data[reg_name] = "N/A"
        export_rows.append(row_data)

    df = pd.DataFrame(export_rows)
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="PFAS Report", index=False)
        worksheet = writer.sheets["PFAS Report"]
        fill_red = PatternFill(start_color="FF9999", end_color="FF9999", fill_type="solid")
        # Apply color if concentration exceeds limit
        for idx, row in enumerate(export_rows, start=2):
            for reg_name, col_name in regulations:
                cell = worksheet[f"{chr(65 + df.columns.get_loc(reg_name))}{idx}"]
                limit_val = getattr(results[idx-2], col_name)
                conc_val = float(results[idx-2].concentration_ppm or 0)
                if limit_val is not None and conc_val > limit_val:
                    cell.fill = fill_red
        # Optional: adjust column widths
        for col in worksheet.columns:
            max_length = max(len(str(cell.value)) if cell.value else 0 for cell in col)
            worksheet.column_dimensions[col[0].column_letter].width = max_length + 2

    buf.seek(0)
    return FileResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        filename=f"PFAS_Report_{sku}.xlsx")
