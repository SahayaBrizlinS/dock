from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from sqlalchemy import create_engine, Column, String, Numeric
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# ======================
# Database Config (like your Flask code)
# ======================
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "PFAS_1")

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


# ======================
# SQLAlchemy Model
# ======================
class Result(Base):
    __tablename__ = "result"

    material_id = Column(String(100), primary_key=True, nullable=False)
    material_name = Column(String(100))
    cas_number = Column(String(255))
    chemical_name = Column(String(500))
    concentration_ppm = Column(Numeric(10, 4))
    supplier_name = Column(String(255))
    reference_doc = Column(String(255))


# Make sure table exists
Base.metadata.create_all(bind=engine)


# ======================
# Pydantic Schema
# ======================
class MaterialSchema(BaseModel):
    material_id: str
    material_name: str = ""
    cas_number: str
    chemical_name: str
    quantity: str
    supplier_name: str


# ======================
# FastAPI App
# ======================
app = FastAPI(title="PFAS Result Loader")


@app.post("/load-materials")
def load_materials(materials: List[MaterialSchema]):
    session = SessionLocal()
    try:
        for m in materials:
            # Convert "200 ppm" safely → float
            try:
                ppm_value = float(str(m.quantity).lower().replace("ppm", "").strip())
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid quantity format for material_id {m.material_id}: {m.quantity}"
                )

            reference = f"{m.material_id}_{m.supplier_name.replace(' ', '_')}.pdf"

            new_record = Result(
                material_id=m.material_id,
                material_name=m.material_name,
                cas_number=m.cas_number,
                chemical_name=m.chemical_name,
                concentration_ppm=ppm_value,
                supplier_name=m.supplier_name,
                reference_doc=reference
            )

            # If exists → update
            existing = session.query(Result).filter_by(material_id=m.material_id).first()
            if existing:
                existing.material_name = new_record.material_name
                existing.cas_number = new_record.cas_number
                existing.chemical_name = new_record.chemical_name
                existing.concentration_ppm = new_record.concentration_ppm
                existing.supplier_name = new_record.supplier_name
                existing.reference_doc = new_record.reference_doc
            else:
                session.add(new_record)

        session.commit()
        return {"success": True, "message": "Materials loaded successfully"}

    except Exception as e:
        session.rollback()
        # Expose the actual DB error for debugging
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")

    finally:
        session.close()
