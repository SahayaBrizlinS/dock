# app.py
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from config import Config
from io import BytesIO
import pandas as pd
import logging
from openpyxl.styles import PatternFill

# ==================== FLASK APP CONFIG ====================

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = 'your-super-secret-key'

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
app.logger.setLevel(logging.INFO)

# Database
db = SQLAlchemy(app)

# ==================== DATABASE MODELS ====================

class PFASBOM(db.Model):
    __tablename__ = 'pfas_bom'
    
    sku = db.Column(db.String(100), primary_key=True)
    component = db.Column(db.String(100), primary_key=True)
    subcomponent = db.Column(db.String(100), primary_key=True)
    material = db.Column(db.String(100), primary_key=True)

    product = db.Column(db.String(100), nullable=False)
    component_description = db.Column(db.String(100), nullable=False)
    subcomponent_description = db.Column(db.String(100), nullable=False)
    material_name = db.Column(db.String(100), nullable=False)
    portal_name = db.Column(db.String(100), nullable=False)
    region = db.Column(db.String(100))
    assessment = db.Column(db.String(100))

    # New column
    flag = db.Column(db.Boolean, nullable=False, default=False)


class PFASMaterialChemicals(db.Model):
    __tablename__ = 'result'

    material_id = db.Column(db.String(100), primary_key=True)
    cas_number = db.Column(db.String(255))
    material_name = db.Column(db.String(100))
    chemical_name = db.Column(db.String(500))
    concentration_ppm = db.Column(db.Numeric(10, 4))
    supplier_name = db.Column(db.String(255))
    reference_doc = db.Column(db.String(255))  # ✅ corrected name


class PFASRegulations(db.Model):
    __tablename__ = 'pfas_regulations'
    
    cas_number = db.Column(db.String(255), primary_key=True)
    chemical_name = db.Column(db.String(500))
    molecular_formula = db.Column(db.String(255))
    structure_category_name = db.Column(db.String(255))
    australian_aics = db.Column(db.Integer)
    australian_imap_tier_2 = db.Column(db.Integer)
    canadian_dsl = db.Column(db.Integer)
    canada_pctsr_2012 = db.Column(db.Integer)
    eu_reach_pre_registered = db.Column(db.Integer)
    eu_reach_registered_ppm = db.Column(db.Integer)
    us_epa_tscainventory = db.Column(db.Integer)
    us_epa_tsca12b = db.Column(db.Integer)

# ==================== ROUTES ====================

@app.route('/')
def index():
    app.logger.info("Loading index page")
    try:
        results = db.session.query(
            PFASBOM.sku,
            PFASBOM.product,
            PFASBOM.portal_name,
            PFASBOM.region,
            PFASBOM.assessment
        ).distinct(PFASBOM.sku).all()
        
        app.logger.info(f"Found {len(results)} distinct products")
        
        products = []
        for row in results:
            products.append({
                'sku': row.sku,
                'product_name': f"{row.sku}_{row.product}",
                'portal_name': row.portal_name,
                'region': row.region or "Global",
                'assessment': row.assessment or "PFAS"
            })
        
        return render_template('index.html', products=products)
        
    except Exception as e:
        app.logger.error(f"Error loading products: {e}", exc_info=True)
        flash("Error loading products", "danger")
        return render_template('index.html', products=[])

@app.route('/filter')
def filter():
    return render_template('filterpage.html')

@app.route('/upload', methods=['POST'])
def upload_bom():
    app.logger.info("Starting BOM upload")
    
    file = request.files.get('file')
    if not file:
        flash("No file uploaded.", "danger")
        return redirect(url_for('index'))
    
    regions = ",".join(request.form.getlist('regions')) or "Global"
    assessments = ",".join(request.form.getlist('assessments')) or "PFAS"
    portal_name = "SAP"
    
    try:
        file_stream = file.stream.read()
        file_buffer = BytesIO(file_stream)
        filename = file.filename.lower()
        
        if filename.endswith('.csv'):
            df = pd.read_csv(file_buffer, dtype=str)
        elif filename.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(file_buffer, sheet_name=0, dtype=str)
        else:
            flash("Unsupported file type. Please upload CSV or Excel.", "danger")
            return redirect(url_for('index'))
        
        # Normalize columns
        df.columns = [
            str(col).strip().replace('\n', '').replace('\r', '').replace(' ', '_').lower() 
            for col in df.columns
        ]
        
        required_cols = {
            'sku': ['sku', 'product_id', 'part_number'],
            'product': ['product', 'product_name', 'product_desc'],
            'component': ['component', 'comp', 'component_id'],
            'component_description': ['component_description', 'comp_desc', 'component_desc'],
            'subcomponent': ['subcomponent', 'sub_comp', 'subcomponent_id'],
            'subcomponent_description': ['subcomponent_description', 'sub_comp_desc', 'subcomponent_desc'],
            'material': ['material', 'mat_id', 'material_id'],
            'material_name': ['material_name', 'mat_name', 'material_desc']
        }
        
        col_map = {}
        for target, possible_names in required_cols.items():
            found = next((name for name in possible_names if name in df.columns), None)
            if not found:
                flash(f"Missing required column: {target}", "danger")
                return redirect(url_for('index'))
            col_map[target] = found

        inserted, updated, skipped = 0, 0, 0

        for index, row in df.iterrows():
            try:
                sku_val = str(row[col_map['sku']]).strip().split('.')[0]
                product_val = str(row[col_map['product']]).strip()
                material_val = str(row[col_map['material']]).strip().split('.')[0]
                
                if not all([sku_val, product_val, material_val]) or 'nan' in [sku_val, material_val]:
                    skipped += 1
                    continue

                # ✅ check if BOM already exists
                existing = db.session.query(PFASBOM).filter_by(
                    sku=sku_val,
                    material=material_val
                ).first()

                if existing:
                    # Update existing record
                    existing.product = product_val
                    existing.component = str(row[col_map['component']]).strip().split('.')[0]
                    existing.component_description = str(row[col_map['component_description']]).strip()
                    existing.subcomponent = str(row[col_map['subcomponent']]).strip()
                    existing.subcomponent_description = str(row[col_map['subcomponent_description']]).strip()
                    existing.material_name = str(row[col_map['material_name']]).strip()
                    existing.portal_name = portal_name
                    existing.region = regions
                    existing.assessment = assessments
                    updated += 1
                else:
                    # Insert new record
                    bom_item = PFASBOM(
                        sku=sku_val,
                        material=material_val,
                        product=product_val,
                        component=str(row[col_map['component']]).strip().split('.')[0],
                        component_description=str(row[col_map['component_description']]).strip(),
                        subcomponent=str(row[col_map['subcomponent']]).strip(),
                        subcomponent_description=str(row[col_map['subcomponent_description']]).strip(),
                        material_name=str(row[col_map['material_name']]).strip(),
                        portal_name=portal_name,
                        region=regions,
                        assessment=assessments
                    )
                    db.session.add(bom_item)
                    inserted += 1
            except Exception as e:
                app.logger.error(f"Row {index} error: {e}")
                skipped += 1
        
        db.session.commit()
        flash(f"✅ Upload complete: {inserted} inserted, {updated} updated, {skipped} skipped.", "success")
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Upload failed: {e}", exc_info=True)
        flash("❌ Error processing file.", "danger")
    
    return redirect(url_for('index'))
@app.route('/api/pfas-assessment/<sku>')
def pfas_assessment(sku):
    bom_rows = db.session.query(PFASBOM).filter_by(sku=sku).all()
    if not bom_rows:
        return jsonify({"error": "SKU not found"}), 404

    first_row = bom_rows[0]
    product_name = f"{first_row.sku}_{first_row.product}"
    
    materials = [row.material for row in bom_rows]
    
    try:
        results = db.session.query(
            PFASBOM.component,
            PFASBOM.subcomponent,
            PFASBOM.material,
            PFASBOM.material_name,
            PFASMaterialChemicals.cas_number,
            PFASMaterialChemicals.chemical_name,
            PFASMaterialChemicals.concentration_ppm,
            PFASMaterialChemicals.supplier_name,
            PFASRegulations.australian_aics,
            PFASRegulations.australian_imap_tier_2,
            PFASRegulations.canadian_dsl,
            PFASRegulations.canada_pctsr_2012,
            PFASRegulations.eu_reach_pre_registered,
            PFASRegulations.eu_reach_registered_ppm,
            PFASRegulations.us_epa_tscainventory,
            PFASRegulations.us_epa_tsca12b
        ).join(PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id)\
         .outerjoin(PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number)\
         .filter(PFASBOM.sku == sku).all()
    except Exception as e:
        app.logger.error(f"Join failed: {e}")
        return jsonify({"error": "Failed to retrieve data"}), 500

    if not results:
        return jsonify({
            "product": product_name,
            "summary": {"total": 0, "non_conforming": 0, "in_conformance": 0},
            "data": []
        })

    # Define regulations with names and column names
    regulations = [
        {'name': 'Australian AICS', 'col': 'australian_aics'},
        {'name': 'Australian IMAP Tier 2', 'col': 'australian_imap_tier_2'},
        {'name': 'Canadian DSL', 'col': 'canadian_dsl'},
        {'name': 'Canada PCTSR 2012', 'col': 'canada_pctsr_2012'},
        {'name': 'EU REACH Pre Registered', 'col': 'eu_reach_pre_registered'},
        {'name': 'EU REACH Registered', 'col': 'eu_reach_registered_ppm'},
        {'name': 'US EPA TSCA Inventory', 'col': 'us_epa_tscainventory'},
        {'name': 'US EPA TSCA 12B', 'col': 'us_epa_tsca12b'}
    ]

    data = []
    non_conforming_count = 0

    for row in results:
        conc = float(row.concentration_ppm) if row.concentration_ppm else 0.0
        cas = row.cas_number or "Unknown"
        chem_name = row.chemical_name or "Unknown"

        limits = []
        is_non_conforming = False

        for reg in regulations:
            value = getattr(row, reg['col'], None)
            if value is None:
                continue
            threshold = float(value)

            # Check: if threshold < concentration → Non-Conforming
            if threshold < conc:
                status = 'exceeded'
                color = 'danger'
                is_non_conforming = True
            else:
                status = 'within'
                color = 'success'

            limits.append({
                'name': reg['name'],
                'limit': f"{threshold} ppm",
                'status': status,
                'color': color
            })

        if is_non_conforming:
            non_conforming_count += 1

        data.append({
            "component": row.component or "-",
            "subcomponent": row.subcomponent or "-",
            "material": row.material or "-",
            "material_name": row.material_name or "-",
            "supplier_name": row.supplier_name or "-",
            "chemical_name": chem_name,
            "cas_number": cas,
            "concentration": f"{conc:.2f} ppm",
            "limits": limits,
            "status": "Non-Conforming" if is_non_conforming else "Conforming",
            "status_color": "danger" if is_non_conforming else "success"
        })

    in_conformance_count = len(data) - non_conforming_count

    return jsonify({
        "product": product_name,
        "summary": {
            "total": len(data),
            "non_conforming": non_conforming_count,
            "in_conformance": in_conformance_count
        },
        "data": data
    })

@app.route('/download-bom/<sku>')
def download_bom(sku):
    app.logger.info(f"Downloading BOM for SKU: {sku}")

    bom_data = db.session.query(PFASBOM).filter_by(sku=sku).all()

    if not bom_data:
        flash("No BOM data found for this SKU.", "danger")
        return redirect(url_for('index'))

    data = []
    for row in bom_data:
        data.append({
            'SKU': row.sku,
            'Product': row.product,
            'Component': row.component,
            'Component Description': row.component_description,
            'Sub-Component': row.subcomponent,
            'Sub-Component Description': row.subcomponent_description,
            'Material': row.material,
            'Material Name': row.material_name,
            'Portal Name': row.portal_name,
            'Region': row.region,
            'Assessment': row.assessment
        })

    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='BOM Details', index=False)
    output.seek(0)

    filename = f"BOM_{sku}.xlsx"
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


@app.route('/api/delete-product/<sku>', methods=['DELETE'])
def delete_product(sku):
    """Delete a product and all its BOM entries"""
    app.logger.info(f"Attempting to delete product with SKU: {sku}")
    
    try:
        # Find all BOM entries for this SKU
        bom_entries = db.session.query(PFASBOM).filter_by(sku=sku).all()
        
        if not bom_entries:
            app.logger.warning(f"No BOM entries found for SKU: {sku}")
            return jsonify({"error": "Product not found"}), 404
        
        # Get product name for response
        product_name = f"{bom_entries[0].sku}_{bom_entries[0].product}" if bom_entries else sku
        
        # Delete all BOM entries for this SKU
        deleted_count = db.session.query(PFASBOM).filter_by(sku=sku).delete()
        
        # Commit the deletion
        db.session.commit()
        
        app.logger.info(f"Successfully deleted {deleted_count} BOM entries for SKU: {sku}")
        
        return jsonify({
            "success": True,
            "message": f"Product '{product_name}' deleted successfully",
            "deleted_count": deleted_count,
            "sku": sku
        }), 200
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error deleting product {sku}: {e}", exc_info=True)
        return jsonify({
            "error": "Failed to delete product. Please try again.",
            "details": str(e)
        }), 500

@app.route('/assessment/<sku>')
def assessment_page(sku):
    """Render the standalone assessment page for a product."""
    try:
        # Reuse your existing API logic
        response = pfas_assessment(sku)
        data = response.get_json()

        if response.status_code != 200 or "error" in data:
            flash("Assessment data not found for this product.", "warning")
            return redirect(url_for('index'))

        product_name = data.get("product", f"{sku}_Unknown")
        return render_template('assessment.html', sku=sku, product_name=product_name, initial_data=data)

    except Exception as e:
        app.logger.error(f"Error loading assessment page for {sku}: {e}")
        flash("Failed to load assessment.", "danger")
        return redirect(url_for('index'))
    
@app.route('/api/export-pfas-report/<sku>')
def export_pfas_report(sku):
    """
    Exports a comprehensive PFAS report for a single SKU.
    Includes BOM, chemical details, and regulatory limits with compliance status.
    """
    app.logger.info(f"📥 Generating PFAS report for SKU: {sku}")

    try:
        # Fetch BOM entries for the SKU
        bom_entries = db.session.query(PFASBOM).filter_by(sku=sku).all()
        if not bom_entries:
            return jsonify({"error": "SKU not found"}), 404

        product_name = bom_entries[0].product

        # Regulation columns
        regulation_columns = [
            'australian_aics',
            'australian_imap_tier_2',
            'canadian_dsl',
            'canada_pctsr_2012',
            'eu_reach_pre_registered',
            'eu_reach_registered_ppm',
            'us_epa_tscainventory',
            'us_epa_tsca12b'
        ]

        # Build the full query
        query = db.session.query(
            PFASBOM.sku,
            PFASBOM.product,
            PFASBOM.component,
            PFASBOM.component_description,
            PFASBOM.subcomponent,
            PFASBOM.subcomponent_description,
            PFASBOM.material,
            PFASBOM.material_name,
            PFASMaterialChemicals.cas_number,
            PFASMaterialChemicals.chemical_name,
            PFASMaterialChemicals.concentration_ppm,
            PFASMaterialChemicals.supplier_name,
            PFASMaterialChemicals.reference,
            PFASRegulations.australian_aics,
            PFASRegulations.australian_imap_tier_2,
            PFASRegulations.canadian_dsl,
            PFASRegulations.canada_pctsr_2012,
            PFASRegulations.eu_reach_pre_registered,
            PFASRegulations.eu_reach_registered_ppm,
            PFASRegulations.us_epa_tscainventory,
            PFASRegulations.us_epa_tsca12b
        ).join(PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id)\
         .outerjoin(PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number)\
         .filter(PFASBOM.sku == sku)

        results = query.all()
        app.logger.info(f"📊 PFAS report query returned {len(results)} rows")

        if not results:
            return jsonify({"error": "No chemical data found for this SKU"}), 400

        # Prepare data for DataFrame
        rows = []
        for r in results:
            conc = float(r.concentration_ppm) if r.concentration_ppm is not None else 0.0

            row = {
                "SKU": r.sku or "",
                "Product": r.product or "",
                "Component": r.component or "",
                "Component Description": r.component_description or "",
                "Sub-Component": r.subcomponent or "",
                "Sub-Component Description": r.subcomponent_description or "",
                "Material ID": r.material or "",
                "Material Name": r.material_name or "",
                "CAS Number": r.cas_number or "Unknown",
                "Chemical Name": r.chemical_name or "Unknown",
                "Chemical Concentration (ppm)": f"{conc:.2f} ppm",
                "Supplier Name": r.supplier_name or "Unknown",
                "Reference": r.reference or ""
            }

            # Add regulation thresholds and compliance status
            for col in regulation_columns:
                value = getattr(r, col, None)
                if value is None:
                    row[col] = "No Data"
                else:
                    threshold = float(value)
                    status = "Non-Compliant" if conc > threshold else "Compliant"
                    row[col] = {
                        "value": threshold,
                        "status": "exceeded" if conc > threshold else "within"
                    }

            rows.append(row)

        # Create DataFrame
        df_data = []
        for row in rows:
            flat_row = {k: (v["value"] if isinstance(v, dict) else v) for k, v in row.items()}
            # Format ppm values
            if "Chemical Concentration (ppm)" not in flat_row:
                conc_val = row.get("Chemical Concentration (ppm)", "0.00 ppm")
                flat_row["Chemical Concentration (ppm)"] = conc_val
            df_data.append(flat_row)

        df = pd.DataFrame(df_data)

        # Write to Excel with styling
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='PFAS Assessment', index=False)
            worksheet = writer.sheets['PFAS Assessment']

            # Styling
            red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")  # Light red
            green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")  # Light green

            # Apply coloring for regulation columns
            start_row = 2
            col_idx_map = {col: df.columns.get_loc(col) + 1 for col in regulation_columns}
            for r_idx, row in enumerate(rows):
                for reg_col in regulation_columns:
                    if reg_col not in col_idx_map:
                        continue
                    cell = worksheet.cell(row=start_row + r_idx, column=col_idx_map[reg_col])
                    value_obj = row[reg_col]
                    if isinstance(value_obj, dict):
                        if value_obj["status"] == "exceeded":
                            cell.fill = red_fill
                        else:
                            cell.fill = green_fill

            # Auto-adjust column widths
            for i, col in enumerate(df.columns):
                max_len = max(df[col].astype(str).map(len).max(), len(col)) + 2
                worksheet.column_dimensions[chr(65 + i)].width = min(max_len, 50)

        output.seek(0)
        timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M")
        filename = f"PFAS_Report_{sku}_{timestamp}.xlsx"

        app.logger.info(f"✅ PFAS report generated: {filename}")

        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )

    except Exception as e:
        app.logger.error(f"❌ Failed to generate PFAS report for {sku}: {e}", exc_info=True)
        return jsonify({"error": "Failed to generate report. Please try again."}), 500


@app.route("/download/pfas/<sku>")
def download_pfas_report(sku):
    try:
        app.logger.info(f"📥 Generating PFAS report for SKU={sku}")

        # Regulation columns to include
        regulation_columns = [
            'australian_aics',
            'australian_imap_tier_2',
            'canadian_dsl',
            'canada_pctsr_2012',
            'eu_reach_pre_registered',
            'eu_reach_registered_ppm',
            'us_epa_tscainventory',
            'us_epa_tsca12b'
        ]

        # Build query: Join BOM → Chemicals → Regulations
        query = db.session.query(
            PFASBOM.sku,
            PFASBOM.product,
            PFASBOM.component,
            PFASBOM.component_description,
            PFASBOM.subcomponent,
            PFASBOM.subcomponent_description,
            PFASBOM.material,
            PFASBOM.material_name,
            PFASMaterialChemicals.cas_number,
            PFASMaterialChemicals.chemical_name,
            PFASMaterialChemicals.concentration_ppm,
            PFASMaterialChemicals.supplier_name,
            PFASMaterialChemicals.reference,
            # Regulation thresholds
            PFASRegulations.australian_aics,
            PFASRegulations.australian_imap_tier_2,
            PFASRegulations.canadian_dsl,
            PFASRegulations.canada_pctsr_2012,
            PFASRegulations.eu_reach_pre_registered,
            PFASRegulations.eu_reach_registered_ppm,
            PFASRegulations.us_epa_tscainventory,
            PFASRegulations.us_epa_tsca12b
        ).join(PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id) \
         .outerjoin(PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number) \
         .filter(PFASBOM.sku == sku)

        results = query.all()
        app.logger.info(f"📊 Query returned {len(results)} rows")

        if not results:
            return jsonify({"error": "No matching records found"}), 400

        # Prepare rows
        rows = []
        for r in results:
            conc = float(r.concentration_ppm) if r.concentration_ppm is not None else 0.0

            row = {
                "SKU": r.sku or "",
                "Product": r.product or "",
                "Component": r.component or "",
                "Component Description": r.component_description or "",
                "Sub-Component": r.subcomponent or "",
                "Sub-Component Description": r.subcomponent_description or "",
                "Material ID": r.material or "",
                "Material Name": r.material_name or "",
                "CAS Number": r.cas_number or "Unknown",
                "Chemical Name": r.chemical_name or "Unknown",
                "Chemical Concentration": f"{conc:.2f} ppm",
                "Supplier Name": r.supplier_name or "Unknown",
                "Reference": r.reference or ""
            }

            # Add regulation values
            for col in regulation_columns:
                value = getattr(r, col, None)
                if value is None:
                    row[col] = "No Data"
                else:
                    threshold = float(value)
                    row[col] = {
                        "value": threshold,
                        "status": "exceeded" if conc > threshold else "within"
                    }

            rows.append(row)

        # Flatten for DataFrame
        df_data = []
        for row in rows:
            flat = {k: v for k, v in row.items() if not isinstance(v, dict)}
            for col in regulation_columns:
                if isinstance(row[col], dict):
                    flat[col] = f"{row[col]['value']} ppm"
                else:
                    flat[col] = row[col]
            df_data.append(flat)

        df = pd.DataFrame(df_data)

        # Write to Excel with coloring
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='PFAS Report', index=False)
            worksheet = writer.sheets['PFAS Report']

            # Coloring
            red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
            green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

            start_row = 2
            for idx, row in enumerate(rows):
                for col_idx, col_name in enumerate(regulation_columns):
                    cell = worksheet.cell(row=start_row + idx, column=df.columns.get_loc(col_name) + 1)
                    value_obj = row[col_name]
                    if isinstance(value_obj, dict):
                        if value_obj["status"] == "exceeded":
                            cell.fill = red_fill
                        else:
                            cell.fill = green_fill

            # Auto-fit column width
            for i, col in enumerate(df.columns):
                max_len = max(df[col].astype(str).map(len).max(), len(col))
                worksheet.column_dimensions[chr(65 + i)].width = min(max_len + 2, 50)

        output.seek(0)
        now = pd.Timestamp.now().strftime("%Y%m%d_%H%M")
        filename = f"PFAS_Report_{sku}_{now}.xlsx"

        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )

    except Exception as e:
        app.logger.error(f"❌ PFAS report export failed: {e}", exc_info=True)
        return jsonify({"error": "Export failed. Please try again."}), 500
    
# ==================== FILTER PAGE API ENDPOINTS ====================
@app.route('/api/skus')
def get_skus():
    try:
        results = db.session.query(PFASBOM.sku, PFASBOM.product).distinct(PFASBOM.sku).all()
        data = [f"{r.sku} - {r.product}" for r in results]
        return jsonify({"skus": data})
    except Exception as e:
        app.logger.error(f"Error fetching SKUs: {e}")
        return jsonify({"skus": []}), 500
    
@app.route('/api/components')
def get_components():
    skus = request.args.get('skus', '')
    if not skus:
        return jsonify({"components": []})
    
    sku_list = [s.split(' - ')[0] for s in skus.split(',')]
    
    try:
        results = db.session.query(
            PFASBOM.component,
            PFASBOM.component_description
        ).filter(PFASBOM.sku.in_(sku_list)).distinct().all()
        
        components = [f"{r.component} - {r.component_description}" for r in results]
        return jsonify({"components": components})
    except Exception as e:
        app.logger.error(f"Error fetching components: {e}")
        return jsonify({"components": []}), 500

    
@app.route('/api/subcomponents')
def get_subcomponents():
    skus = request.args.get('skus', '')
    components = request.args.get('components', '')
    
    if not skus or not components:
        return jsonify({"subcomponents": []})
    
    sku_list = [s.split(' - ')[0] for s in skus.split(',')]
    comp_list = [c.split(' - ')[0] for c in components.split(',')]
    
    try:
        results = db.session.query(
            PFASBOM.subcomponent,
            PFASBOM.subcomponent_description
        ).filter(
            PFASBOM.sku.in_(sku_list),
            PFASBOM.component.in_(comp_list)
        ).distinct().all()
        
        subcomponents = [f"{r.subcomponent} - {r.subcomponent_description}" for r in results]
        return jsonify({"subcomponents": subcomponents})
    except Exception as e:
        app.logger.error(f"Error fetching subcomponents: {e}")
        return jsonify({"subcomponents": []}), 500

@app.route('/api/materials')
def get_materials():
    skus = request.args.get('skus', '')
    components = request.args.get('components', '')
    subcomponents = request.args.get('subcomponents', '')
    
    if not all([skus, components, subcomponents]):
        return jsonify({"materials": []})
    
    sku_list = [s.split(' - ')[0] for s in skus.split(',')]
    comp_list = [c.split(' - ')[0] for c in components.split(',')]
    sub_list = [s.split(' - ')[0] for s in subcomponents.split(',')]

    try:
        results = db.session.query(
            PFASBOM.material,
            PFASBOM.material_name
        ).filter(
            PFASBOM.sku.in_(sku_list),
            PFASBOM.component.in_(comp_list),
            PFASBOM.subcomponent.in_(sub_list)
        ).distinct().all()
        
        materials = [f"{r.material} - {r.material_name}" for r in results]
        return jsonify({"materials": materials})
    except Exception as e:
        app.logger.error(f"Error fetching materials: {e}")
        return jsonify({"materials": []}), 500

    
@app.route('/api/filter-results')
def filter_results():
    skus = request.args.get('skus', '')
    components = request.args.get('components', '')
    subcomponents = request.args.get('subcomponents', '')
    materials = request.args.get('materials', '')
    region = request.args.get('region', '')

    valid_columns = [
        'australian_aics',
        'australian_imap_tier_2',
        'canadian_dsl',
        'canada_pctsr_2012',
        'eu_reach_pre_registered',
        'eu_reach_registered_ppm',
        'us_epa_tscainventory',
        'us_epa_tsca12b'
    ]

    if not skus or region not in valid_columns:
        return jsonify({"data": []})

    sku_list = [s.split(' - ')[0] for s in skus.split(',')]
    comp_list = [c.split(' - ')[0] for c in components.split(',')] if components else None
    sub_list = [s.split(' - ')[0] for s in subcomponents.split(',')] if subcomponents else None
    mat_list = [m.split(' - ')[0] for m in materials.split(',')] if materials else None

    try:
        query = db.session.query(
            PFASBOM.sku,
            PFASBOM.product,
            PFASBOM.component,
            PFASBOM.component_description,
            PFASBOM.subcomponent,
            PFASBOM.subcomponent_description,
            PFASBOM.material,
            PFASBOM.material_name,
            PFASMaterialChemicals.chemical_name,
            PFASMaterialChemicals.cas_number,
            PFASMaterialChemicals.concentration_ppm,
            PFASMaterialChemicals.supplier_name,
            getattr(PFASRegulations, region).label("limit_value")
        ).join(
            PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id
        ).outerjoin(
            PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number
        ).filter(PFASBOM.sku.in_(sku_list))

        if comp_list:
            query = query.filter(PFASBOM.component.in_(comp_list))
        if sub_list:
            query = query.filter(PFASBOM.subcomponent.in_(sub_list))
        if mat_list:
            query = query.filter(PFASBOM.material.in_(mat_list))

        results = query.all()

        data = []
        for r in results:
            conc = float(r.concentration_ppm) if r.concentration_ppm else 0.0
            limit = float(r.limit_value) if r.limit_value is not None else None

            if limit is None:
                status = "No Data"
                color = "warning"
            elif limit < conc:
                status = "Non-Compliant"
                color = "danger"
            else:
                status = "Compliant"
                color = "success"

            data.append({
                "sku": f"{r.sku} - {r.product}" if r.product else r.sku,
                "component": f"{r.component} - {r.component_description}" if r.component_description else r.component,
                "subcomponent": f"{r.subcomponent} - {r.subcomponent_description}" if r.subcomponent_description else r.subcomponent,
                "material": f"{r.material} - {r.material_name}" if r.material_name else r.material,
                "cas_number": r.cas_number or "Unknown",
                "chemical_name": r.chemical_name or "Unknown",
                "concentration": f"{conc:.2f} ppm",
                "supplier_name": r.supplier_name or "Unknown",
                "status": status,
                "status_color": color
            })

        return jsonify({"data": data})

    except Exception as e:
        app.logger.error(f"Filter results error: {e}")
        return jsonify({"data": []}), 500

@app.route('/api/export-filter-results', methods=['POST'])
def export_filter_results():
    try:
        app.logger.info("📥 Received export request")

        payload = request.get_json()
        if not payload or "filters" not in payload:
            return jsonify({"error": "Missing filters in request"}), 400

        filters = payload["filters"]
        app.logger.info(f"🔍 Filters received: {filters}")

        # Parse filters (strip " - description" if present)
        skus = [s.split(" - ")[0] for s in filters.get("skus", [])]
        components = [c.split(" - ")[0] for c in filters.get("components", [])]
        subcomponents = [sc.split(" - ")[0] for sc in filters.get("subcomponents", [])]
        materials = [m.split(" - ")[0] for m in filters.get("materials", [])]

        if not skus:
            return jsonify({"error": "No valid SKUs provided"}), 400

        # Regulation columns to include
        regulation_columns = [
            "australian_aics",
            "australian_imap_tier_2",
            "canadian_dsl",
            "canada_pctsr_2012",
            "eu_reach_pre_registered",
            "eu_reach_registered_ppm",
            "us_epa_tscainventory",
            "us_epa_tsca12b"
        ]

        # Build query
        query = db.session.query(
            PFASBOM.sku,
            PFASBOM.product,
            PFASBOM.component,
            PFASBOM.component_description,
            PFASBOM.subcomponent,
            PFASBOM.subcomponent_description,
            PFASBOM.material,
            PFASBOM.material_name,
            PFASMaterialChemicals.cas_number,
            PFASMaterialChemicals.chemical_name,
            PFASMaterialChemicals.concentration_ppm,
            PFASMaterialChemicals.supplier_name,
            PFASMaterialChemicals.reference,
            *[getattr(PFASRegulations, col) for col in regulation_columns]
        ).join(
            PFASMaterialChemicals, PFASBOM.material == PFASMaterialChemicals.material_id
        ).outerjoin(
            PFASRegulations, PFASMaterialChemicals.cas_number == PFASRegulations.cas_number
        ).filter(PFASBOM.sku.in_(skus))

        if components:
            query = query.filter(PFASBOM.component.in_(components))
        if subcomponents:
            query = query.filter(PFASBOM.subcomponent.in_(subcomponents))
        if materials:
            query = query.filter(PFASBOM.material.in_(materials))

        results = query.all()
        app.logger.info(f"📊 Query returned {len(results)} rows")

        if not results:
            return jsonify({"error": "No matching records found"}), 400

        # Convert query results → flat rows
        rows = []
        for r in results:
            conc = float(r.concentration_ppm) if r.concentration_ppm else 0.0

            row = {
                "SKU": r.sku or "",
                "Product": r.product or "",
                "Component": r.component or "",
                "Component Description": r.component_description or "",
                "Sub-Component": r.subcomponent or "",
                "Sub-Component Description": r.subcomponent_description or "",
                "Material ID": r.material or "",
                "Material Name": r.material_name or "",
                "CAS Number": r.cas_number or "Unknown",
                "Chemical Name": r.chemical_name or "Unknown",
                "Chemical Concentration": f"{conc:.2f} ppm",
                "Supplier Name": r.supplier_name or "Unknown",
                "Reference": r.reference or ""
            }

            # Add regulation thresholds + status
            for col in regulation_columns:
                threshold = getattr(r, col, None)
                if threshold is None:
                    row[col] = "No Data"
                else:
                    threshold_val = float(threshold)
                    row[col] = f"{threshold_val} ppm"
                    row[f"{col}_status"] = "exceeded" if conc > threshold_val else "within"

            rows.append(row)

        # Convert to DataFrame (ignore *_status for sheet layout)
        df = pd.DataFrame([{k: v for k, v in row.items() if not k.endswith("_status")} for row in rows])

        # Write Excel
        output = BytesIO()
        with pd.ExcelWriter(output, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Results", index=False)
            ws = writer.sheets["Results"]

            # Coloring
            red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
            green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")

            # Apply fills row by row
            for i, row in enumerate(rows, start=2):  # Excel rows start at 2 (after header)
                for col_idx, col in enumerate(regulation_columns, start=1):
                    cell = ws.cell(row=i, column=df.columns.get_loc(col) + 1)
                    status = row.get(f"{col}_status")
                    if status == "exceeded":
                        cell.fill = red_fill
                    elif status == "within":
                        cell.fill = green_fill

            # Auto column width
            for col_cells in ws.columns:
                max_length = max(len(str(cell.value)) if cell.value else 0 for cell in col_cells)
                ws.column_dimensions[col_cells[0].column_letter].width = min(max_length + 2, 50)

        output.seek(0)
        filename = f"PFAS_Filter_Report_{pd.Timestamp.now().strftime('%Y%m%d_%H%M')}.xlsx"

        app.logger.info(f"✅ Export successful: {len(rows)} rows exported")
        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    except Exception as e:
        app.logger.error(f"❌ Export failed: {e}", exc_info=True)
        return jsonify({"error": "Export failed. Please try again."}), 500
    
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        app.logger.info("Database tables created")
    app.run(debug=True)