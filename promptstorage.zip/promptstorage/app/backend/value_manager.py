from fastapi import APIRouter, Request, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Boolean, select, insert, update, delete
from starlette.status import HTTP_303_SEE_OTHER
import os


DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")  # use 'db' if running inside container
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

#DATABASE_URL = "postgresql://baxterdev:Password123@localhost:5432/baxterdb"
engine = create_engine(DATABASE_URL)
metadata = MetaData()

values_table = Table(
    "values_table",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String),
    Column("standard_value", String),
    Column("prompt_value", String),
    Column("filter", String),
    Column("active", Boolean),
)

metadata.create_all(engine)

router = APIRouter()
templates = Jinja2Templates(directory="templates")


@router.get("/values")
def list_values(request: Request, msg: str = ""):
    with engine.connect() as conn:
        result = conn.execute(select(values_table)).fetchall()
    return templates.TemplateResponse("values.html", {"request": request, "values": result, "msg": msg})


@router.get("/values/add")
def show_add_form(request: Request, msg: str = ""):
    return templates.TemplateResponse("add_value.html", {"request": request, "msg": msg})


@router.post("/values/add")
def submit_add_form(
    request: Request,
    name: str = Form(...),
    standard_value: str = Form(...),
    prompt_value: str = Form(...),
    filter: str = Form(...),
    active: bool = Form(False)
):
    with engine.begin() as conn:
        conn.execute(insert(values_table).values(
            name=name,
            standard_value=standard_value,
            prompt_value=prompt_value,
            filter=filter,
            active=active
        ))
    return RedirectResponse(url="/values/add?msg=Value+added+successfully", status_code=HTTP_303_SEE_OTHER)


@router.get("/values/edit/{value_id}")
def show_edit_form(value_id: int, request: Request, msg: str = ""):
    with engine.connect() as conn:
        result = conn.execute(select(values_table).where(values_table.c.id == value_id)).fetchone()
    return templates.TemplateResponse("edit_value.html", {"request": request, "value": result, "msg": msg})


@router.post("/values/edit/{value_id}")
def submit_edit_form(
    request: Request,
    value_id: int,
    name: str = Form(...),
    standard_value: str = Form(...),
    prompt_value: str = Form(...),
    filter: str = Form(...),
    active: bool = Form(False)
):
    with engine.begin() as conn:
        conn.execute(update(values_table).where(values_table.c.id == value_id).values(
            name=name,
            standard_value=standard_value,
            prompt_value=prompt_value,
            filter=filter,
            active=active
        ))
    return RedirectResponse(url=f"/values/edit/{value_id}?msg=Value+updated+successfully", status_code=HTTP_303_SEE_OTHER)


@router.get("/values/delete/{value_id}")
def delete_value(value_id: int):
    with engine.begin() as conn:
        conn.execute(delete(values_table).where(values_table.c.id == value_id))
    return RedirectResponse(url="/values?msg=Value+deleted", status_code=HTTP_303_SEE_OTHER)
