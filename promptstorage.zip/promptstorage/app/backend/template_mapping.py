from fastapi import APIRouter, Request, Body
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text
from typing import List, Dict, Any
import os
from datetime import datetime
 
router = APIRouter()
templates = Jinja2Templates(directory="templates")
 
# DB connection
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)
 
@router.get("/template-mapping", response_class=HTMLResponse)
def template_source_mapping_page(request: Request):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT client
            FROM template
            WHERE client IS NOT NULL AND client <> ''
            ORDER BY client
        """)).fetchall()
    return templates.TemplateResponse("template_mapping.html", {"request": request, "clients": [r[0] for r in rows]})
 
@router.get("/api/product-families/{client}")
def get_product_families(client: str):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT productfamily
            FROM template
            WHERE client = :client
            AND productfamily IS NOT NULL AND productfamily <> ''
            ORDER BY productfamily
        """), {"client": client}).fetchall()
    return JSONResponse({"families": [r[0] for r in rows]})
 
@router.get("/api/products/{client}/{family}")
def get_products(client: str, family: str):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT product
            FROM template
            WHERE client = :client
              AND productfamily = :family
              AND product IS NOT NULL AND product <> ''
            ORDER BY product
        """), {"client": client, "family": family}).fetchall()
    return JSONResponse({"products": [r[0] for r in rows]})
 
@router.get("/api/templates/{client}/{family}/{product}")
def get_templates(client: str, family: str, product: str):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DISTINCT templatename
            FROM template
            WHERE client = :client
              AND productfamily = :family
              AND product = :product
              AND isactive = TRUE
              AND templatename IS NOT NULL AND templatename <> ''
            ORDER BY templatename
        """), {"client": client, "family": family, "product": product}).fetchall()
    return JSONResponse({"templates": [r[0] for r in rows]})
 
@router.get("/api/file-options")
def get_file_options():
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT originalfilename, alias
            FROM file_uploads
            ORDER BY originalfilename
        """)).fetchall()
 
    def mk(row):
        orig, alias = row
        return {"display": f"{orig} | {alias}", "alias": alias}
 
    pdf = [mk(r) for r in rows if r[0].lower().endswith(".pdf")]
    excel = [mk(r) for r in rows if r[0].lower().endswith((".xlsx", ".xls", ".csv"))]
 
    return JSONResponse({"pdfOptions": pdf, "excelOptions": excel, "urlOptions": []})
 
@router.post("/api/save-mapping")
def save_mapping(payload: Dict[str, Any] = Body(...)):
    client = payload.get("client")
    family = payload.get("productFamily")
    product = payload.get("product")
    tname = payload.get("templatename")
    selections: List[Dict[str, str]] = payload.get("selections", [])
    if not all([client, family, product, tname]):
        return JSONResponse({"ok": False, "message": "Missing required fields"}, status_code=400)
    rows_to_insert = [
        {"client": client, "productfamily": family, "product": product,
         "templatename": tname, "aliasname": s["alias"], "sourcetype": s["sourcetype"],
         "createdon": datetime.utcnow()}
        for s in selections if s.get("alias")
    ]
    if not rows_to_insert:
        return JSONResponse({"ok": False, "message": "No selections"}, status_code=400)
    with engine.begin() as conn:
        conn.execute(text("""
            INSERT INTO templatesource_map
                (client, productfamily, product, templatename, aliasname, sourcetype, createdon)
            VALUES
                (:client, :productfamily, :product, :templatename, :aliasname, :sourcetype, :createdon)
        """), rows_to_insert)
    return JSONResponse({"ok": True, "message": "Mapping saved successfully"})
 

 