import os
from datetime import datetime
from fastapi import APIRouter, Request, Form, status, UploadFile, File
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, text, MetaData
from urllib.parse import quote_plus  # Add this import at the top
 
router = APIRouter()
templates = Jinja2Templates(directory="templates")
 
# DB config
DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
 
engine = create_engine(DATABASE_URL)
metadata = MetaData()
 
UPLOAD_DIR = "uploaded_templates"
os.makedirs(UPLOAD_DIR, exist_ok=True)
 
@router.get("/templatedownload")
def client_product_report(request: Request):
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT client, product_family, product, template_name, last_generated_on, file_path
            FROM client_product_template
            ORDER BY last_generated_on DESC
        """))
        rows = [dict(row) for row in result.mappings()]
    return templates.TemplateResponse("template_download.html", {"request": request, "data": rows})
 
@router.get("/template")
def form_page(request: Request, msg: str | None = None):
    with engine.connect() as conn:
        clients = conn.execute(
            text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client'")
        ).fetchall()
        clients = [row[0] for row in clients]
    return templates.TemplateResponse("template_form.html", {
        "request": request,
        "clients": clients,
        "message": msg
    })
 
@router.get("/get-product-families/{client}")
def get_product_families(client: str):
    with engine.connect() as conn:
        families = conn.execute(text("""
            SELECT entity_value FROM public.aira_hierarchy
            WHERE parent = :client AND entity_type = 'ProductFamily'
        """), {"client": client}).fetchall()
        families = [row[0] for row in families]
    return JSONResponse(content={"families": families})
 
@router.get("/get-products/{product_family}")
def get_products(product_family: str):
    with engine.connect() as conn:
        products = conn.execute(text("""
            SELECT entity_value FROM public.aira_hierarchy
            WHERE parent = :family AND entity_type = 'Product'
        """), {"family": product_family}).fetchall()
        products = [row[0] for row in products]
    return JSONResponse(content={"products": products})
 
@router.post("/submit-template")
async def submit_template(
    client: str = Form(...),
    productFamily: str = Form(...),
    product: str = Form(...),
    templateName: str = Form(...),
    outputTemplateFile: UploadFile = File(...),
    templateStartRow: str = Form(...),
    templateStartColumn: str = Form(...)
):
    # Save uploaded file
    file_ext = os.path.splitext(outputTemplateFile.filename)[1]
    safe_filename = f"{templateName}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}{file_ext}"
    save_path = os.path.join(UPLOAD_DIR, safe_filename)
 
    with open(save_path, "wb") as buffer:
        buffer.write(await outputTemplateFile.read())
 
    # Insert into DB with saved file path
    with engine.connect() as conn:
        insert_query = text("""
            INSERT INTO template
            ("client", "productfamily", "product", "templatename", "version", "isactive", "createdon", "outputtemplatepath", "templatestartrow", "templatestartcolumn")
            VALUES
            (:client, :productFamily, :product, :templateName, :version, :isActive, :createdOn, :outputTemplatePath, :startRow, :startColumn)
        """)
        conn.execute(insert_query, {
            "client": client,
            "productFamily": productFamily,
            "product": product,
            "templateName": templateName,
            "version": 1,
            "isActive": True,
            "createdOn": datetime.utcnow(),
            "outputTemplatePath": save_path,
            "startRow": templateStartRow,
            "startColumn": templateStartColumn
        })
        conn.commit()
 
    return RedirectResponse(url="/template?msg=Template+saved+successfully", status_code=status.HTTP_303_SEE_OTHER)

@router.get("/api/templates")
def get_templates(page: int = 1, limit: int = 10):
    offset = (page - 1) * limit

    try:
        with engine.connect() as conn:
            # Fetch paginated templates - include outputtemplatepath, exclude version/isactive
            result = conn.execute(
                text("""
                    SELECT 
                        templateid, client, productfamily, product, templatename, 
                        createdon, templatestartrow, templatestartcolumn, outputtemplatepath
                    FROM template
                    ORDER BY createdon DESC
                    LIMIT :limit OFFSET :offset
                """),
                {"limit": limit, "offset": offset}
            )
            rows = result.fetchall()

            # Get total count
            total_result = conn.execute(
                text("SELECT COUNT(*) FROM template")
            )
            total = total_result.scalar()

            # Format data
            data = []
            for row in rows:
                data.append({
                    "id": row.templateid,
                    "client": row.client or "",
                    "productFamily": row.productfamily or "",
                    "product": row.product or "",
                    "templateName": row.templatename or "",
                    "outputTemplatePath": row.outputtemplatepath or "N/A",
                    "createdOn": row.createdon.strftime("%Y-%m-%d %H:%M") if row.createdon else "N/A",
                    "startRow": row.templatestartrow or "",
                    "startColumn": row.templatestartcolumn or ""
                })

            return JSONResponse({
                "data": data,
                "total": total,
                "page": page,
                "totalPages": (total + limit - 1) // limit
            })
    except Exception as e:
        print(f"Error fetching templates: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": "Failed to fetch templates"}
        )

@router.post("/update-template-inline")
def update_template_inline(
    templateid: int = Form(...),
    client: str = Form(...),
    productFamily: str = Form(...),
    product: str = Form(...),
    templateName: str = Form(...),
    outputTemplatePath: str = Form(...),  # New field
    startRow: str = Form(...),
    startColumn: str = Form(...)
):
    try:
        with engine.begin() as conn:
            # Check for duplicate template name (excluding current)
            existing = conn.execute(
                text("SELECT templateid FROM template WHERE templatename = :templateName AND templateid != :templateid"),
                {"templateName": templateName, "templateid": templateid}
            ).fetchone()
            if existing:
                msg = f"Template+name+'{quote_plus(templateName)}'+already+exists."
                return RedirectResponse(f"/template?msg={msg}", status_code=status.HTTP_303_SEE_OTHER)

            # Update the record (without version/isactive)
            conn.execute(
                text("""
                    UPDATE template SET
                        client = :client,
                        productfamily = :productFamily,
                        product = :product,
                        templatename = :templateName,
                        outputtemplatepath = :outputTemplatePath,
                        templatestartrow = :startRow,
                        templatestartcolumn = :startColumn
                    WHERE templateid = :templateid
                """),
                {
                    "templateid": templateid,
                    "client": client,
                    "productFamily": productFamily,
                    "product": product,
                    "templateName": templateName,
                    "outputTemplatePath": outputTemplatePath,
                    "startRow": startRow,
                    "startColumn": startColumn
                }
            )
        msg = "Template+updated+successfully"
    except Exception as e:
        msg = f"Error+updating+template%3A+{str(e)}"

    return RedirectResponse(f"/template?msg={msg}", status_code=status.HTTP_303_SEE_OTHER)

@router.post("/delete-template-inline")
def delete_template_inline(templateid: int = Form(...)):
    try:
        with engine.begin() as conn:
            result = conn.execute(
                text("SELECT outputtemplatepath FROM template WHERE templateid = :templateid"),
                {"templateid": templateid}
            )
            row = result.fetchone()
            if not row:
                return RedirectResponse("/template?msg=Template+not+found", status_code=status.HTTP_303_SEE_OTHER)

            file_path = row.outputtemplatepath
            if os.path.exists(file_path):
                os.remove(file_path)
                dir_path = os.path.dirname(file_path)
                if os.path.isdir(dir_path) and not os.listdir(dir_path):
                    os.rmdir(dir_path)

            conn.execute(
                text("DELETE FROM template WHERE templateid = :templateid"),
                {"templateid": templateid}
            )
        msg = "Template+deleted+successfully"
    except Exception as e:
        msg = f"Error+deleting+template%3A+{str(e)}"

    return RedirectResponse(f"/template?msg={msg}", status_code=status.HTTP_303_SEE_OTHER)