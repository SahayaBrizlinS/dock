from fastapi import APIRouter, Request, Form, Query
from fastapi.responses import HTMLResponse, RedirectResponse,JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, Text, select, and_, text
import os
from datetime import datetime
router = APIRouter()

templates = Jinja2Templates(directory="templates")

DB_USER = os.getenv("DB_USER", "baxterdev")
DB_PASSWORD = os.getenv("DB_PASSWORD", "Password123")
DB_HOST = os.getenv("DB_HOST", "localhost")  # use 'db' if running inside container
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "baxterdb")
DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

#DATABASE_URL = "postgresql://baxterdev:Password123@localhost:5432/baxterdb"
engine = create_engine(DATABASE_URL)
metadata = MetaData()

# prompts = Table(
#     "prompts",
#     metadata,
#     Column("id", Integer, primary_key=True),
#     Column("prompt_name", String(100)),
#     Column("set_name", String(100)),
#     Column("document_name", String(100)),
#     Column("document_alias_name", String(100)),
#     Column("prompt_text", Text)
# )

metadata.create_all(engine)

@router.get("/")
def home(request: Request):
    return templates.TemplateResponse("home.html", {"request": request})


@router.get("/prompts", response_class=HTMLResponse)
async def prompt_tabs(request: Request):
    with engine.connect() as conn:
        # Existing prompts data
        # result = conn.execute(select(prompts)).fetchall()
        # sets = conn.execute(select(prompts.c.set_name).distinct()).scalars().all()
        # docs = conn.execute(select(prompts.c.document_name).distinct()).scalars().all()

        # set_doc_map = {}
        # rows = conn.execute(select(prompts.c.set_name, prompts.c.document_name)).fetchall()
        # for set_name, doc_name in rows:
        #     set_doc_map.setdefault(set_name, set()).add(doc_name)

        # # New: Fetch clients for create_prompt3.html
        query = text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE entity_type = 'Client'
        """)
        result_clients = conn.execute(query).fetchall()
        clients = [row[0] for row in result_clients]

    return templates.TemplateResponse("prompt_tabs.html", {
        "request": request,
        # "prompts": result,
        # "sets": sets,
        # "docs": docs,
        # "set_doc_map": dict((k, list(v)) for k, v in set_doc_map.items()),
        "clients": clients  # Pass this for create_prompt3.html
    })




@router.get("/create", response_class=HTMLResponse)
async def create_prompt_form(request: Request):
    with engine.connect() as conn:
        query = text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE entity_type = 'Client'
        """)
        result = conn.execute(query).fetchall()
        clients = [row[0] for row in result]

    return templates.TemplateResponse("create_prompt3.html",
        {"request": request,
          "clients": clients 
          }
    )


@router.get("/get_product_families/{client}")
async def get_product_families(client: str):
    with engine.connect() as conn:
        query = text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE parent = :client 
            AND entity_type = 'ProductFamily'
        """)
        result = conn.execute(query, {"client": client}).fetchall()
        return JSONResponse([row[0] for row in result])

@router.get("/get_aliases")
async def get_aliases():
    with engine.connect() as conn:
        query = text("SELECT aliasname FROM public.aliases")
        result = conn.execute(query).fetchall()
        return JSONResponse([row[0] for row in result])

# Fetch templates for a product family
@router.get("/get_templates/{product_family}")
async def get_templates(product_family: str):
    with engine.connect() as conn:
        query = text("""
            SELECT entity_value 
            FROM public.aira_hierarchy 
            WHERE parent = :pf 
            AND entity_type = 'Product'
        """)
        result = conn.execute(query, {"pf": product_family}).fetchall()
        return JSONResponse([row[0] for row in result])



from datetime import datetime


@router.post("/save-prompt", response_class=HTMLResponse)
def save_prompt(
    request: Request,
    client: str = Form(...),
    product_family: str = Form(...),
    template: str = Form(...),
    document_alias: str = Form(...),
    prompt_name: str = Form(...),
    prompt_text: str = Form(...)
):
    insert_query = text("""
        INSERT INTO prompts 
        (client, product_family, product, document_alias_name, prompt_name, prompt_text, created_on)
        VALUES 
        (:client, :product_family, :template, :document_alias, :prompt_name, :prompt_text, :created_on)
    """)
    with engine.connect() as conn:
        conn.execute(insert_query, {
            "client": client,
            "product_family": product_family,
            "template": template,
            "document_alias": document_alias,
            "prompt_name": prompt_name,
            "prompt_text": prompt_text,
            "created_on": datetime.utcnow()
        })
        conn.commit()

    return templates.TemplateResponse("create_prompt3.html", {
        "request": request,
        "message": "✅ Prompt saved successfully!"
    })


@router.get("/view-prompts", response_class=HTMLResponse)
async def view_prompts(
    request: Request,
    client: str = Query(default=""),
    product_family: str = Query(default=""),
    product: str = Query(default="")
):
    with engine.connect() as conn:
        # Fetch clients for dropdown
        clients = [row[0] for row in conn.execute(
            text("SELECT entity_value FROM public.aira_hierarchy WHERE entity_type = 'Client'")
        ).fetchall()]

        # Fetch product families for selected client
        product_families = []
        if client:
            product_families = [row[0] for row in conn.execute(
                text("""
                    SELECT entity_value FROM public.aira_hierarchy 
                    WHERE parent = :client AND entity_type = 'ProductFamily'
                """), {"client": client}
            ).fetchall()]

        # Fetch products for selected product family
        products = []
        if product_family:
            products = [row[0] for row in conn.execute(
                text("""
                    SELECT entity_value FROM public.aira_hierarchy 
                    WHERE parent = :pf AND entity_type = 'Product'
                """), {"pf": product_family}
            ).fetchall()]

        # Build base query for prompts
        query_str = "SELECT * FROM prompts WHERE 1=1"
        params = {}

        if client:
            query_str += " AND client = :client"
            params["client"] = client

        if product_family:
            query_str += " AND product_family = :product_family"
            params["product_family"] = product_family

        if product:
            query_str += " AND product = :product"
            params["product"] = product

        query = text(query_str)
        prompts = conn.execute(query, params).fetchall()

    # Convert prompts (RowProxy) to list of dicts for easier Jinja2 access (optional)
    prompts_list = [dict(row) for row in prompts]

    return templates.TemplateResponse("view_prompts2.html", {
        "request": request,
        "clients": clients,
        "product_families": product_families,
        "products": products,
        "prompts": prompts_list,
        "selected_client": client,
        "selected_product_family": product_family,
        "selected_product": product,
    })

# @router.get("/edit/{prompt_id}", response_class=HTMLResponse)
# async def edit_prompt(request: Request, prompt_id: int):
#     with engine.connect() as conn:
#         prompt = conn.execute(select(prompts).where(prompts.c.id == prompt_id)).first()
#     if not prompt:
#         return HTMLResponse(content="❌ Prompt not found", status_code=404)
#     return templates.TemplateResponse("edit_prompt.html", {"request": request, "prompt": prompt})

# @router.post("/update/{prompt_id}", response_class=HTMLResponse)
# async def update_prompt(request: Request, prompt_id: int,
#                         prompt_name: str = Form(...),
#                         set_name: str = Form(...),
#                         document_name: str = Form(...),
#                         document_alias_name: str = Form(...),
#                         prompt_text: str = Form(...)):
#     with engine.begin() as conn:
#         conn.execute(prompts.update().where(prompts.c.id == prompt_id).values(
#             prompt_name=prompt_name,
#             set_name=set_name,
#             document_name=document_name,
#             document_alias_name=document_alias_name,
#             prompt_text=prompt_text
#         ))
#     return RedirectResponse(url="/view-prompts?message=Prompt+updated+successfully", status_code=303)

# @router.get("/delete/{prompt_id}")
# async def delete_prompt(prompt_id: int):
#     with engine.begin() as conn:
#         conn.execute(prompts.delete().where(prompts.c.id == prompt_id))
#     return RedirectResponse(url="/view-prompts?message=Prompt+deleted+successfully", status_code=303)
